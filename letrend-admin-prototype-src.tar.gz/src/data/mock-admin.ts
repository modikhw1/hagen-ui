// Mock data for the admin dashboard prototype

export interface TeamMember {
  id: string;
  name: string;
  email: string;
  role: string;
  avatar_url?: string;
  color: string;
  is_active: boolean;
  city?: string;
  bio?: string;
  started_at?: string;
}

export interface CustomerProfile {
  id: string;
  business_name: string;
  contact_email: string;
  customer_contact_name?: string;
  phone?: string;
  account_manager?: string;
  account_manager_profile_id?: string;
  monthly_price: number;
  subscription_interval: "month" | "quarter" | "year";
  pricing_status: "fixed" | "unknown";
  status: "active" | "agreed" | "invited" | "pending" | "archived";
  created_at: string;
  stripe_customer_id?: string;
  stripe_subscription_id?: string;
  next_invoice_date?: string;
  discount_type?: "none" | "percent" | "amount" | "free_months";
  discount_value?: number;
  tiktok_handle?: string;
  upload_schedule?: string[]; // e.g. ["mon","wed","fri"]
  last_upload_at?: string;
}

export interface CMActivity {
  id: string;
  cm_id: string;
  cm_name: string;
  type: "concept_sent" | "concept_uploaded" | "feedback" | "mail" | "note" | "upload";
  description: string;
  customer_name: string;
  customer_id: string;
  created_at: string;
}

export interface InvoiceSummary {
  id: string;
  customer_name: string;
  customer_id: string;
  amount_due: number;
  status: "paid" | "open" | "void" | "draft";
  created_at: string;
  due_date?: string;
  line_items?: InvoiceLineItem[];
}

export interface InvoiceLineItem {
  description: string;
  amount: number;
  quantity: number;
}

export interface SubscriptionSummary {
  id: string;
  customer_name: string;
  customer_id: string;
  amount: number;
  interval: "month" | "quarter" | "year";
  status: "active" | "trialing" | "past_due" | "canceled" | "incomplete";
  cancel_at_period_end: boolean;
  current_period_end?: string;
  stripe_subscription_id?: string;
}

export interface SyncStatus {
  customer_id: string;
  customer_name: string;
  stripe_synced: boolean;
  stripe_last_sync?: string;
  stripe_error?: string;
  tiktok_connected: boolean;
  tiktok_last_fetch?: string;
  tiktok_error?: string;
}

export interface CostEntry {
  service: string;
  calls_30d: number;
  cost_30d: number;
  trend: number[];
}

export interface TikTokStats {
  followers: number;
  follower_delta_7d: number;
  follower_delta_30d: number;
  avg_views_7d: number;
  avg_views_30d: number;
  engagement_rate: number;
  total_videos: number;
  videos_last_7d: number;
  follower_history_30d: number[]; // 30 data points
  views_history_30d: number[];
}

export interface CMHoverData {
  planned_clips: number;
  last_concept_added: string | null;
  customers_last_upload: { name: string; date: string | null }[];
  expected_events_today: number;
}

// ---- Mock Data ----

export const mockTeam: TeamMember[] = [
  { id: "cm-1", name: "Alma Lindqvist", email: "alma@letrend.se", role: "content_manager", color: "#6B4423", is_active: true, city: "Stockholm", bio: "Kreativ strateg med fokus på restauranger", started_at: "2025-08-01T00:00:00Z" },
  { id: "cm-2", name: "Erik Sandström", email: "erik@letrend.se", role: "content_manager", color: "#8B6914", is_active: true, city: "Göteborg", bio: "Tidigare bartender, nu content creator", started_at: "2025-10-15T00:00:00Z" },
  { id: "cm-3", name: "Nora Beijer", email: "nora@letrend.se", role: "content_manager", color: "#5A8F5A", is_active: true, city: "Malmö", bio: "Specialiserad på caféer och bagerier", started_at: "2026-01-10T00:00:00Z" },
];

export const mockCustomers: CustomerProfile[] = [
  { id: "c-1", business_name: "Café Rosé", contact_email: "info@caferose.se", customer_contact_name: "Maria Holm", phone: "070-123 45 67", account_manager: "Alma Lindqvist", monthly_price: 3500, subscription_interval: "month", pricing_status: "fixed", status: "active", created_at: "2025-11-15T10:00:00Z", stripe_customer_id: "cus_1", stripe_subscription_id: "sub_1", next_invoice_date: "2026-05-01T00:00:00Z", tiktok_handle: "@caferose_sthlm", upload_schedule: ["mon", "wed", "fri"], last_upload_at: "2026-04-14T18:00:00Z" },
  { id: "c-2", business_name: "Bar Centrale", contact_email: "hej@barcentrale.se", customer_contact_name: "Johan Berg", phone: "073-456 78 90", account_manager: "Alma Lindqvist", monthly_price: 4200, subscription_interval: "month", pricing_status: "fixed", status: "active", created_at: "2025-12-01T10:00:00Z", stripe_customer_id: "cus_2", stripe_subscription_id: "sub_2", next_invoice_date: "2026-05-01T00:00:00Z", tiktok_handle: "@barcentrale", upload_schedule: ["tue", "thu"], last_upload_at: "2026-04-15T08:00:00Z" },
  { id: "c-3", business_name: "Noodle House", contact_email: "info@noodlehouse.se", customer_contact_name: "Li Wei", phone: "072-111 22 33", account_manager: "Erik Sandström", monthly_price: 2800, subscription_interval: "month", pricing_status: "fixed", status: "active", created_at: "2026-01-10T10:00:00Z", stripe_customer_id: "cus_3", stripe_subscription_id: "sub_3", next_invoice_date: "2026-05-10T00:00:00Z", tiktok_handle: "@noodlehouse_se", upload_schedule: ["mon", "thu", "sat"], last_upload_at: "2026-04-13T12:00:00Z" },
  { id: "c-4", business_name: "Trattoria Bella", contact_email: "bella@trattoria.se", customer_contact_name: "Marco Ricci", account_manager: "Erik Sandström", monthly_price: 3500, subscription_interval: "month", pricing_status: "fixed", status: "agreed", created_at: "2026-02-20T10:00:00Z", stripe_customer_id: "cus_4", stripe_subscription_id: "sub_4", tiktok_handle: "@trattoriabella", upload_schedule: ["wed", "sat"], last_upload_at: "2026-04-10T15:00:00Z" },
  { id: "c-5", business_name: "Sushi Zen", contact_email: "info@sushizen.se", customer_contact_name: "Yuki Tanaka", phone: "070-999 88 77", account_manager: "Nora Beijer", monthly_price: 3200, subscription_interval: "month", pricing_status: "fixed", status: "active", created_at: "2026-03-01T10:00:00Z", stripe_customer_id: "cus_5", stripe_subscription_id: "sub_5", next_invoice_date: "2026-05-01T00:00:00Z", tiktok_handle: "@sushizen_se", upload_schedule: ["mon", "wed", "fri"], last_upload_at: "2026-04-15T10:00:00Z" },
  { id: "c-6", business_name: "Brew & Co", contact_email: "hello@brewco.se", customer_contact_name: "Saga Nordin", account_manager: "Nora Beijer", monthly_price: 0, subscription_interval: "month", pricing_status: "unknown", status: "invited", created_at: "2026-04-01T10:00:00Z" },
  { id: "c-7", business_name: "Pasta Palace", contact_email: "info@pastapalace.se", customer_contact_name: "Anders Lund", monthly_price: 0, subscription_interval: "month", pricing_status: "unknown", status: "pending", created_at: "2026-04-10T10:00:00Z" },
  { id: "c-8", business_name: "Old Café", contact_email: "old@cafe.se", account_manager: "Alma Lindqvist", monthly_price: 2500, subscription_interval: "month", pricing_status: "fixed", status: "archived", created_at: "2025-06-01T10:00:00Z" },
];

export const mockActivities: CMActivity[] = [
  { id: "a-1", cm_id: "cm-1", cm_name: "Alma Lindqvist", type: "concept_sent", description: "Skickade koncept till kund", customer_name: "Café Rosé", customer_id: "c-1", created_at: "2026-04-15T09:30:00Z" },
  { id: "a-2", cm_id: "cm-2", cm_name: "Erik Sandström", type: "concept_uploaded", description: "Laddade upp nytt koncept", customer_name: "Noodle House", customer_id: "c-3", created_at: "2026-04-15T08:45:00Z" },
  { id: "a-3", cm_id: "cm-1", cm_name: "Alma Lindqvist", type: "feedback", description: "Kommenterade på kundens klipp", customer_name: "Bar Centrale", customer_id: "c-2", created_at: "2026-04-14T16:20:00Z" },
  { id: "a-4", cm_id: "cm-3", cm_name: "Nora Beijer", type: "mail", description: "Skickade veckorapport", customer_name: "Sushi Zen", customer_id: "c-5", created_at: "2026-04-14T14:00:00Z" },
  { id: "a-5", cm_id: "cm-2", cm_name: "Erik Sandström", type: "concept_sent", description: "Skickade koncept", customer_name: "Trattoria Bella", customer_id: "c-4", created_at: "2026-04-14T11:30:00Z" },
  { id: "a-6", cm_id: "cm-3", cm_name: "Nora Beijer", type: "note", description: "Intern notering om strategi", customer_name: "Sushi Zen", customer_id: "c-5", created_at: "2026-04-13T15:00:00Z" },
  { id: "a-7", cm_id: "cm-1", cm_name: "Alma Lindqvist", type: "concept_uploaded", description: "Laddade upp koncept", customer_name: "Bar Centrale", customer_id: "c-2", created_at: "2026-04-13T10:00:00Z" },
  { id: "a-8", cm_id: "cm-2", cm_name: "Erik Sandström", type: "feedback", description: "Gav feedback på kundens profil", customer_name: "Noodle House", customer_id: "c-3", created_at: "2026-04-12T16:45:00Z" },
  { id: "a-9", cm_id: "cm-1", cm_name: "Alma Lindqvist", type: "concept_uploaded", description: "Laddade upp koncept", customer_name: "Café Rosé", customer_id: "c-1", created_at: "2026-04-12T09:00:00Z" },
  { id: "a-10", cm_id: "cm-3", cm_name: "Nora Beijer", type: "concept_sent", description: "Skickade koncept", customer_name: "Sushi Zen", customer_id: "c-5", created_at: "2026-04-11T11:00:00Z" },
];

export const mockCosts: CostEntry[] = [
  { service: "Google Cloud (Vertex + GCS)", calls_30d: 352, cost_30d: 31.55, trend: [10, 12, 11, 14, 12, 15, 11, 13, 12, 14, 11, 13, 12, 15, 10, 12, 11, 14, 12, 15, 11, 13, 12, 14, 11, 13, 12, 15, 10, 12] },
  { service: "Gemini API", calls_30d: 89, cost_30d: 6.70, trend: [2, 3, 3, 4, 2, 3, 3, 2, 4, 3, 2, 3, 3, 4, 2, 3, 3, 2, 4, 3, 2, 3, 3, 4, 2, 3, 3, 2, 4, 3] },
  { service: "TikTok Fetcher", calls_30d: 720, cost_30d: 14.40, trend: [24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24] },
  { service: "Supabase", calls_30d: 4200, cost_30d: 25.00, trend: [120, 130, 140, 150, 135, 145, 155, 140, 130, 145, 135, 150, 140, 155, 120, 130, 140, 150, 135, 145, 155, 140, 130, 145, 135, 150, 140, 155, 120, 130] },
  { service: "Stripe", calls_30d: 180, cost_30d: 8.50, trend: [5, 6, 7, 5, 6, 8, 5, 6, 7, 5, 6, 8, 5, 6, 7, 5, 6, 8, 5, 6, 7, 5, 6, 8, 5, 6, 7, 5, 6, 8] },
  { service: "Resend", calls_30d: 87, cost_30d: 0, trend: [2, 4, 3, 5, 2, 3, 4, 2, 4, 3, 5, 2, 3, 4, 2, 4, 3, 5, 2, 3, 4, 2, 4, 3, 5, 2, 3, 4, 2, 4] },
];

export const mockInvoices: InvoiceSummary[] = [
  { id: "inv-1", customer_name: "Café Rosé", customer_id: "c-1", amount_due: 350000, status: "paid", created_at: "2026-04-01T00:00:00Z", line_items: [{ description: "Content curation – månadsabonnemang", amount: 350000, quantity: 1 }] },
  { id: "inv-2", customer_name: "Bar Centrale", customer_id: "c-2", amount_due: 420000, status: "paid", created_at: "2026-04-01T00:00:00Z", line_items: [{ description: "Content curation – månadsabonnemang", amount: 420000, quantity: 1 }] },
  { id: "inv-3", customer_name: "Noodle House", customer_id: "c-3", amount_due: 280000, status: "open", created_at: "2026-04-10T00:00:00Z", due_date: "2026-04-25T00:00:00Z", line_items: [{ description: "Content curation – månadsabonnemang", amount: 280000, quantity: 1 }] },
  { id: "inv-4", customer_name: "Sushi Zen", customer_id: "c-5", amount_due: 320000, status: "paid", created_at: "2026-04-01T00:00:00Z", line_items: [{ description: "Content curation – månadsabonnemang", amount: 320000, quantity: 1 }] },
  { id: "inv-5", customer_name: "Trattoria Bella", customer_id: "c-4", amount_due: 400000, status: "open", created_at: "2026-04-20T00:00:00Z", due_date: "2026-05-05T00:00:00Z", line_items: [{ description: "Content curation – månadsabonnemang", amount: 350000, quantity: 1 }, { description: "Inspelningshjälp – extra session", amount: 50000, quantity: 1 }] },
];

export const mockSubscriptions: SubscriptionSummary[] = [
  { id: "sub-1", customer_name: "Café Rosé", customer_id: "c-1", amount: 3500, interval: "month", status: "active", cancel_at_period_end: false, current_period_end: "2026-05-01T00:00:00Z", stripe_subscription_id: "sub_stripe_1" },
  { id: "sub-2", customer_name: "Bar Centrale", customer_id: "c-2", amount: 4200, interval: "month", status: "active", cancel_at_period_end: false, current_period_end: "2026-05-01T00:00:00Z", stripe_subscription_id: "sub_stripe_2" },
  { id: "sub-3", customer_name: "Noodle House", customer_id: "c-3", amount: 2800, interval: "month", status: "active", cancel_at_period_end: false, current_period_end: "2026-05-10T00:00:00Z", stripe_subscription_id: "sub_stripe_3" },
  { id: "sub-4", customer_name: "Trattoria Bella", customer_id: "c-4", amount: 3500, interval: "month", status: "trialing", cancel_at_period_end: false, current_period_end: "2026-05-20T00:00:00Z", stripe_subscription_id: "sub_stripe_4" },
  { id: "sub-5", customer_name: "Sushi Zen", customer_id: "c-5", amount: 3200, interval: "month", status: "active", cancel_at_period_end: true, current_period_end: "2026-05-01T00:00:00Z", stripe_subscription_id: "sub_stripe_5" },
];

export const mockSyncStatuses: SyncStatus[] = [
  { customer_id: "c-1", customer_name: "Café Rosé", stripe_synced: true, stripe_last_sync: "2026-04-15T08:00:00Z", tiktok_connected: true, tiktok_last_fetch: "2026-04-15T06:00:00Z" },
  { customer_id: "c-2", customer_name: "Bar Centrale", stripe_synced: true, stripe_last_sync: "2026-04-15T08:00:00Z", tiktok_connected: true, tiktok_last_fetch: "2026-04-15T06:00:00Z" },
  { customer_id: "c-3", customer_name: "Noodle House", stripe_synced: true, stripe_last_sync: "2026-04-15T08:00:00Z", tiktok_connected: true, tiktok_last_fetch: "2026-04-14T06:00:00Z", tiktok_error: "Rate limit exceeded – retrying" },
  { customer_id: "c-4", customer_name: "Trattoria Bella", stripe_synced: true, stripe_last_sync: "2026-04-15T08:00:00Z", tiktok_connected: false },
  { customer_id: "c-5", customer_name: "Sushi Zen", stripe_synced: false, stripe_error: "Webhook signature invalid", tiktok_connected: true, tiktok_last_fetch: "2026-04-15T06:00:00Z" },
];

export const mockTikTokStats: Record<string, TikTokStats> = {
  "c-1": {
    followers: 2340, follower_delta_7d: 12, follower_delta_30d: 34, avg_views_7d: 1850, avg_views_30d: 1420, engagement_rate: 4.2, total_videos: 47, videos_last_7d: 3,
    follower_history_30d: [1750, 1770, 1790, 1810, 1830, 1850, 1870, 1890, 1920, 1940, 1960, 1980, 2000, 2020, 2040, 2060, 2080, 2100, 2120, 2140, 2160, 2180, 2200, 2220, 2240, 2260, 2280, 2300, 2320, 2340],
    views_history_30d: [1200, 1400, 1100, 1800, 2200, 1500, 1300, 1600, 1900, 1100, 1400, 1700, 2000, 1300, 1500, 1800, 2100, 1400, 1600, 1900, 1200, 1500, 1800, 2100, 1400, 1600, 1900, 1700, 1850, 1850],
  },
  "c-2": {
    followers: 5120, follower_delta_7d: -3, follower_delta_30d: 8, avg_views_7d: 3200, avg_views_30d: 3800, engagement_rate: 3.1, total_videos: 82, videos_last_7d: 2,
    follower_history_30d: [4740, 4760, 4780, 4800, 4830, 4850, 4870, 4900, 4920, 4950, 4970, 4990, 5010, 5030, 5050, 5060, 5070, 5080, 5090, 5100, 5110, 5120, 5130, 5140, 5150, 5140, 5130, 5125, 5120, 5120],
    views_history_30d: [3500, 3800, 4200, 3600, 3400, 3900, 4100, 3700, 3500, 3800, 4000, 3600, 3400, 3900, 4100, 3700, 3500, 3800, 4000, 3600, 3400, 3200, 3100, 3300, 3500, 3200, 3000, 3100, 3200, 3200],
  },
  "c-3": {
    followers: 890, follower_delta_7d: 28, follower_delta_30d: 65, avg_views_7d: 2400, avg_views_30d: 1100, engagement_rate: 6.8, total_videos: 23, videos_last_7d: 4,
    follower_history_30d: [540, 550, 560, 570, 580, 600, 610, 630, 650, 670, 690, 700, 720, 740, 750, 760, 780, 790, 800, 810, 820, 830, 840, 850, 860, 870, 875, 880, 885, 890],
    views_history_30d: [600, 700, 800, 900, 1000, 1100, 1200, 1300, 1400, 1500, 1600, 1700, 1800, 1900, 2000, 2100, 2200, 2300, 2400, 2500, 2200, 2300, 2400, 2500, 2600, 2300, 2400, 2500, 2400, 2400],
  },
  "c-4": {
    followers: 1200, follower_delta_7d: 0, follower_delta_30d: 5, avg_views_7d: 800, avg_views_30d: 750, engagement_rate: 2.9, total_videos: 15, videos_last_7d: 1,
    follower_history_30d: [1140, 1145, 1150, 1155, 1160, 1160, 1165, 1170, 1175, 1175, 1180, 1180, 1185, 1185, 1190, 1190, 1190, 1195, 1195, 1195, 1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200, 1200],
    views_history_30d: [700, 750, 680, 720, 800, 750, 700, 780, 800, 720, 700, 750, 680, 720, 800, 750, 700, 780, 800, 720, 700, 750, 680, 720, 800, 750, 700, 780, 800, 800],
  },
  "c-5": {
    followers: 3400, follower_delta_7d: 8, follower_delta_30d: 22, avg_views_7d: 2800, avg_views_30d: 2200, engagement_rate: 5.1, total_videos: 56, videos_last_7d: 3,
    follower_history_30d: [2790, 2810, 2830, 2860, 2890, 2920, 2950, 2980, 3010, 3040, 3060, 3080, 3100, 3120, 3140, 3160, 3180, 3200, 3220, 3240, 3260, 3280, 3300, 3320, 3340, 3350, 3360, 3370, 3385, 3400],
    views_history_30d: [1800, 2000, 2200, 2400, 2100, 1900, 2300, 2500, 2200, 2000, 2400, 2600, 2300, 2100, 2500, 2700, 2400, 2200, 2600, 2800, 2500, 2300, 2700, 2900, 2600, 2400, 2800, 3000, 2800, 2800],
  },
};

// Mock: pending line items for next invoice per customer
export const mockPendingLineItems: Record<string, InvoiceLineItem[]> = {
  "c-4": [{ description: "Inspelningshjälp – extra session", amount: 50000, quantity: 1 }],
};

// ---- Helpers ----

export function getCMActivityStats(cmId: string) {
  const now = new Date("2026-04-15T12:00:00Z");
  const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
  const activities = mockActivities.filter(
    (a) => a.cm_id === cmId && new Date(a.created_at) >= weekAgo
  );
  return {
    count7d: activities.length,
    latest: activities[0]?.created_at || null,
  };
}

export function getCustomersByCM(cmId: string) {
  const cm = mockTeam.find((t) => t.id === cmId);
  if (!cm) return [];
  return mockCustomers.filter(
    (c) => c.account_manager === cm.name && c.status !== "archived"
  );
}

export function getStats() {
  const active = mockCustomers.filter((c) => c.status === "active" || c.status === "agreed");
  const pipeline = mockCustomers.filter((c) => c.status === "invited" || c.status === "pending");
  const mrr = active.reduce((sum, c) => sum + (c.monthly_price || 0), 0);
  return { mrr, activeCount: active.length, pipelineCount: pipeline.length };
}

export function getTotalCost30d() {
  return mockCosts.reduce((sum, c) => sum + c.cost_30d, 0);
}

// 30-day growth stats
export function getGrowth30d() {
  // Customers added in last 30 days (created_at after 2026-03-16)
  const cutoff = new Date("2026-03-16T00:00:00Z");
  const newCustomers = mockCustomers.filter(c => new Date(c.created_at) >= cutoff && c.status !== "archived");
  const newMRR = newCustomers.reduce((s, c) => s + (c.monthly_price || 0), 0);
  return { count: newCustomers.length, mrr: newMRR };
}

export function getCMHoverData(cmId: string): CMHoverData {
  const cm = mockTeam.find(t => t.id === cmId);
  if (!cm) return { planned_clips: 0, last_concept_added: null, customers_last_upload: [], expected_events_today: 0 };

  const customers = getCustomersByCM(cmId);
  const now = new Date("2026-04-15T12:00:00Z");
  const dayNames = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"];
  const today = dayNames[now.getDay()]; // tuesday

  // Count concepts uploaded by this CM in last 7d
  const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
  const conceptActivities = mockActivities.filter(
    a => a.cm_id === cmId && (a.type === "concept_uploaded" || a.type === "concept_sent") && new Date(a.created_at) >= weekAgo
  );

  // Last concept added
  const lastConcept = mockActivities.find(a => a.cm_id === cmId && a.type === "concept_uploaded");

  // Customers' last upload
  const customerUploads = customers.map(c => ({
    name: c.business_name,
    date: c.last_upload_at || null,
  }));

  // Expected events today based on upload schedules
  const expectedToday = customers.filter(c => c.upload_schedule?.includes(today)).length;

  return {
    planned_clips: conceptActivities.length,
    last_concept_added: lastConcept?.created_at || null,
    customers_last_upload: customerUploads,
    expected_events_today: expectedToday,
  };
}
