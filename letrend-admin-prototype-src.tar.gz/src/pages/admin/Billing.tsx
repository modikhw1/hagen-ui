import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { mockInvoices, mockSubscriptions, mockSyncStatuses } from "@/data/mock-admin";
import { CheckCircle, AlertTriangle, XCircle, ExternalLink, RefreshCw } from "lucide-react";

type BillingTab = "invoices" | "subscriptions" | "health";

function timeAgo(dateStr: string): string {
  const now = new Date("2026-04-15T12:00:00Z");
  const date = new Date(dateStr);
  const diffMs = now.getTime() - date.getTime();
  const hours = Math.floor(diffMs / (1000 * 60 * 60));
  if (hours < 1) return "just nu";
  if (hours < 24) return `${hours}h sedan`;
  const days = Math.floor(hours / 24);
  return `${days}d sedan`;
}

export default function Billing() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<BillingTab>("invoices");
  const [envFilter, setEnvFilter] = useState<"all" | "test" | "live">("all");

  const statusConfig = (status: string) => {
    switch (status) {
      case "paid": return { label: "Betald", className: "bg-success/10 text-success" };
      case "open": return { label: "Obetald", className: "bg-warning/10 text-warning" };
      case "void": return { label: "Annullerad", className: "bg-muted text-muted-foreground" };
      case "draft": return { label: "Utkast", className: "bg-info/10 text-info" };
      default: return { label: status, className: "bg-muted text-muted-foreground" };
    }
  };

  const subStatusConfig = (status: string) => {
    switch (status) {
      case "active": return { label: "Aktiv", className: "bg-success/10 text-success" };
      case "trialing": return { label: "Provperiod", className: "bg-info/10 text-info" };
      case "past_due": return { label: "Förfallen", className: "bg-destructive/10 text-destructive" };
      case "canceled": return { label: "Avslutad", className: "bg-muted text-muted-foreground" };
      case "incomplete": return { label: "Ofullständig", className: "bg-warning/10 text-warning" };
      default: return { label: status, className: "bg-muted text-muted-foreground" };
    }
  };

  const tabs: { key: BillingTab; label: string }[] = [
    { key: "invoices", label: "Fakturor" },
    { key: "subscriptions", label: "Abonnemang" },
    { key: "health", label: "Sync & Health" },
  ];

  const intervalLabel = (i: string) =>
    i === "month" ? "/mån" : i === "quarter" ? "/kvartal" : "/år";

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold font-heading text-foreground">Billing</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Fakturor, abonnemang och synkstatus
          </p>
        </div>
        <div className="flex gap-1 p-1 bg-secondary rounded-md border border-border">
          {(["all", "test", "live"] as const).map((env) => (
            <button
              key={env}
              onClick={() => setEnvFilter(env)}
              className={`px-3 py-1.5 rounded text-xs font-semibold transition-colors ${
                envFilter === env
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {env === "all" ? "Alla miljöer" : env.toUpperCase()}
            </button>
          ))}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 mb-6 border-b border-border">
        {tabs.map((tab) => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            className={`px-4 py-2.5 text-sm font-medium transition-colors border-b-2 -mb-px ${
              activeTab === tab.key
                ? "border-primary text-foreground"
                : "border-transparent text-muted-foreground hover:text-foreground"
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* INVOICES TAB */}
      {activeTab === "invoices" && (
        <div>
          <div className="flex gap-3 mb-5">
            <SummaryCard
              label="Obetalda"
              value={`${(mockInvoices.filter(i => i.status === "open").reduce((s, i) => s + i.amount_due, 0) / 100).toLocaleString("sv-SE")} kr`}
              className="text-warning"
            />
            <SummaryCard
              label="Betalda denna månad"
              value={`${(mockInvoices.filter(i => i.status === "paid").reduce((s, i) => s + i.amount_due, 0) / 100).toLocaleString("sv-SE")} kr`}
              className="text-success"
            />
            <SummaryCard label="Totalt antal" value={String(mockInvoices.length)} />
          </div>

          <div className="bg-card rounded-lg border border-border overflow-hidden">
            <div className="grid grid-cols-[2fr_1fr_1fr_1fr_120px] gap-4 px-5 py-3 bg-secondary/50 border-b border-border text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">
              <div>Kund</div>
              <div>Belopp</div>
              <div>Rader</div>
              <div>Skapad</div>
              <div>Status</div>
            </div>
            {mockInvoices.map((inv, i) => {
              const sc = statusConfig(inv.status);
              return (
                <div
                  key={inv.id}
                  className={`grid grid-cols-[2fr_1fr_1fr_1fr_120px] gap-4 px-5 py-3.5 items-center hover:bg-accent/30 transition-colors cursor-pointer ${
                    i < mockInvoices.length - 1 ? "border-b border-border" : ""
                  }`}
                  onClick={() => navigate(`/admin/customers/${inv.customer_id}`)}
                >
                  <div className="text-sm font-medium text-foreground">{inv.customer_name}</div>
                  <div className="text-sm font-semibold text-foreground">
                    {(inv.amount_due / 100).toLocaleString("sv-SE")} kr
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {inv.line_items?.length || 1} rad{(inv.line_items?.length || 1) > 1 ? "er" : ""}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {new Date(inv.created_at).toLocaleDateString("sv-SE", { day: "numeric", month: "short" })}
                  </div>
                  <div>
                    <span className={`inline-flex px-2.5 py-1 rounded-full text-[11px] font-semibold ${sc.className}`}>
                      {sc.label}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* SUBSCRIPTIONS TAB */}
      {activeTab === "subscriptions" && (
        <div>
          <div className="flex gap-3 mb-5">
            <SummaryCard
              label="Aktiva"
              value={String(mockSubscriptions.filter(s => s.status === "active").length)}
              className="text-success"
            />
            <SummaryCard
              label="Provperiod"
              value={String(mockSubscriptions.filter(s => s.status === "trialing").length)}
              className="text-info"
            />
            <SummaryCard
              label="Avslutas vid periodens slut"
              value={String(mockSubscriptions.filter(s => s.cancel_at_period_end).length)}
              className="text-warning"
            />
          </div>

          <div className="bg-card rounded-lg border border-border overflow-hidden">
            <div className="grid grid-cols-[2fr_1fr_1fr_1fr_120px] gap-4 px-5 py-3 bg-secondary/50 border-b border-border text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">
              <div>Kund</div>
              <div>Belopp</div>
              <div>Perioden slutar</div>
              <div>Avslutas</div>
              <div>Status</div>
            </div>
            {mockSubscriptions.map((sub, i) => {
              const sc = subStatusConfig(sub.status);
              return (
                <div
                  key={sub.id}
                  className={`grid grid-cols-[2fr_1fr_1fr_1fr_120px] gap-4 px-5 py-3.5 items-center hover:bg-accent/30 transition-colors cursor-pointer ${
                    i < mockSubscriptions.length - 1 ? "border-b border-border" : ""
                  }`}
                  onClick={() => navigate(`/admin/customers/${sub.customer_id}`)}
                >
                  <div className="text-sm font-medium text-foreground">{sub.customer_name}</div>
                  <div className="text-sm font-semibold text-foreground">
                    {sub.amount.toLocaleString("sv-SE")} kr{intervalLabel(sub.interval)}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {sub.current_period_end
                      ? new Date(sub.current_period_end).toLocaleDateString("sv-SE")
                      : "—"}
                  </div>
                  <div>
                    {sub.cancel_at_period_end ? (
                      <span className="text-xs font-medium text-warning">Ja</span>
                    ) : (
                      <span className="text-xs text-muted-foreground">Nej</span>
                    )}
                  </div>
                  <div>
                    <span className={`inline-flex px-2.5 py-1 rounded-full text-[11px] font-semibold ${sc.className}`}>
                      {sc.label}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* HEALTH TAB */}
      {activeTab === "health" && (
        <div>
          <div className="flex gap-3 mb-5">
            <SummaryCard
              label="Stripe OK"
              value={String(mockSyncStatuses.filter(s => s.stripe_synced).length)}
              className="text-success"
            />
            <SummaryCard
              label="TikTok OK"
              value={String(mockSyncStatuses.filter(s => s.tiktok_connected && !s.tiktok_error).length)}
              className="text-success"
            />
            <SummaryCard
              label="Problem"
              value={String(mockSyncStatuses.filter(s => s.stripe_error || s.tiktok_error || !s.tiktok_connected).length)}
              className="text-warning"
            />
          </div>

          <div className="bg-card rounded-lg border border-border overflow-hidden">
            <div className="grid grid-cols-[2fr_1fr_1fr_1fr] gap-4 px-5 py-3 bg-secondary/50 border-b border-border text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">
              <div>Kund</div>
              <div>Stripe</div>
              <div>TikTok</div>
              <div>Senaste sync</div>
            </div>
            {mockSyncStatuses.map((sync, i) => (
              <div
                key={sync.customer_id}
                className={`grid grid-cols-[2fr_1fr_1fr_1fr] gap-4 px-5 py-3.5 items-center ${
                  i < mockSyncStatuses.length - 1 ? "border-b border-border" : ""
                }`}
              >
                <div className="text-sm font-medium text-foreground">{sync.customer_name}</div>
                <div className="flex items-center gap-2">
                  {sync.stripe_synced && !sync.stripe_error ? (
                    <CheckCircle className="h-4 w-4 text-success" />
                  ) : sync.stripe_error ? (
                    <XCircle className="h-4 w-4 text-destructive" />
                  ) : (
                    <AlertTriangle className="h-4 w-4 text-warning" />
                  )}
                  <span className="text-xs text-muted-foreground">
                    {sync.stripe_error || (sync.stripe_synced ? "OK" : "Ej synkad")}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  {sync.tiktok_connected && !sync.tiktok_error ? (
                    <CheckCircle className="h-4 w-4 text-success" />
                  ) : sync.tiktok_error ? (
                    <AlertTriangle className="h-4 w-4 text-warning" />
                  ) : (
                    <XCircle className="h-4 w-4 text-muted-foreground" />
                  )}
                  <span className="text-xs text-muted-foreground">
                    {sync.tiktok_error || (sync.tiktok_connected ? "OK" : "Ej kopplad")}
                  </span>
                </div>
                <div className="text-xs text-muted-foreground">
                  {sync.stripe_last_sync ? timeAgo(sync.stripe_last_sync) : "—"}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function SummaryCard({ label, value, className = "" }: { label: string; value: string; className?: string }) {
  return (
    <div className="flex-1 p-4 bg-card rounded-lg border border-border">
      <div className="text-[11px] text-muted-foreground uppercase tracking-wider">{label}</div>
      <div className={`text-xl font-bold mt-1 ${className || "text-foreground"}`}>{value}</div>
    </div>
  );
}
