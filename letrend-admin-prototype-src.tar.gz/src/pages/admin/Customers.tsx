import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { mockCustomers, mockTeam } from "@/data/mock-admin";
import { Search, X, Check, Link, Copy } from "lucide-react";

export default function Customers() {
  const navigate = useNavigate();
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [showInviteModal, setShowInviteModal] = useState(false);

  const filtered = mockCustomers.filter((c) => {
    const matchSearch =
      !search ||
      c.business_name.toLowerCase().includes(search.toLowerCase()) ||
      c.contact_email.toLowerCase().includes(search.toLowerCase());
    const matchStatus =
      statusFilter === "all" ||
      (statusFilter === "active" && (c.status === "active" || c.status === "agreed")) ||
      (statusFilter === "pipeline" && (c.status === "invited" || c.status === "pending")) ||
      c.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const getCM = (name?: string) =>
    mockTeam.find((t) => t.name === name);

  const statusConfig = (status: string) => {
    switch (status) {
      case "active":
      case "agreed":
        return { label: "Aktiv", className: "bg-success/10 text-success" };
      case "invited":
        return { label: "Inbjuden", className: "bg-info/10 text-info" };
      case "pending":
        return { label: "Väntande", className: "bg-warning/10 text-warning" };
      case "archived":
        return { label: "Arkiverad", className: "bg-muted text-muted-foreground" };
      default:
        return { label: status, className: "bg-muted text-muted-foreground" };
    }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold font-heading text-foreground">Kunder</h1>
          <p className="text-sm text-muted-foreground mt-1">
            {filtered.length} kund{filtered.length !== 1 ? "er" : ""}
          </p>
        </div>
        <button
          onClick={() => setShowInviteModal(true)}
          className="px-4 py-2 bg-primary text-primary-foreground rounded-md text-sm font-semibold"
        >
          + Bjud in kund
        </button>
      </div>

      {/* Invite modal */}
      {showInviteModal && (
        <InviteModal onClose={() => setShowInviteModal(false)} />
      )}

      {/* Filters */}
      <div className="flex gap-3 mb-5 flex-wrap">
        <div className="relative flex-1 max-w-xs">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input
            type="text"
            placeholder="Sök kund..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-4 py-2 rounded-md border border-border bg-card text-sm outline-none focus:border-primary/30"
          />
        </div>
        <div className="flex bg-secondary rounded-md p-1 gap-0.5">
          {[
            { key: "all", label: "Alla" },
            { key: "active", label: "Aktiva" },
            { key: "pipeline", label: "Pipeline" },
            { key: "archived", label: "Arkiverade" },
          ].map((f) => (
            <button
              key={f.key}
              onClick={() => setStatusFilter(f.key)}
              className={`px-3 py-1.5 rounded text-xs font-medium transition-colors ${
                statusFilter === f.key
                  ? "bg-card text-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="bg-card rounded-lg border border-border overflow-hidden">
        <div className="grid grid-cols-[2fr_1fr_1fr_1fr_120px] gap-4 px-5 py-3 bg-secondary/50 border-b border-border text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">
          <div>Företag</div>
          <div>CM</div>
          <div>Pris</div>
          <div>Tillagd</div>
          <div>Status</div>
        </div>
        {filtered.length === 0 ? (
          <div className="py-12 text-center text-sm text-muted-foreground">
            Inga kunder hittades.
          </div>
        ) : (
          filtered.map((customer, i) => {
            const cm = getCM(customer.account_manager);
            const sc = statusConfig(customer.status);
            return (
              <div
                key={customer.id}
                className={`grid grid-cols-[2fr_1fr_1fr_1fr_120px] gap-4 px-5 py-3.5 items-center cursor-pointer hover:bg-accent/30 transition-colors ${
                  i < filtered.length - 1 ? "border-b border-border" : ""
                }`}
                onClick={() => navigate(`/admin/customers/${customer.id}`)}
              >
                <div>
                  <div className="text-sm font-semibold text-foreground">
                    {customer.business_name}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {customer.contact_email}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {cm ? (
                    <>
                      <div
                        className="w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold text-primary-foreground shrink-0"
                        style={{ backgroundColor: cm.color }}
                      >
                        {cm.name.charAt(0)}
                      </div>
                      <span className="text-sm text-foreground">{cm.name.split(" ")[0]}</span>
                    </>
                  ) : (
                    <span className="text-xs text-muted-foreground">—</span>
                  )}
                </div>
                <div className="text-sm font-semibold text-foreground">
                  {customer.pricing_status === "unknown"
                    ? "Ej satt"
                    : customer.monthly_price > 0
                      ? `${customer.monthly_price.toLocaleString()} kr`
                      : "—"}
                </div>
                <div className="text-xs text-muted-foreground">
                  {new Date(customer.created_at).toLocaleDateString("sv-SE", {
                    day: "numeric",
                    month: "short",
                  })}
                </div>
                <div>
                  <span
                    className={`inline-flex px-2.5 py-1 rounded-full text-[11px] font-semibold ${sc.className}`}
                  >
                    {sc.label}
                  </span>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}

function InviteModal({ onClose }: { onClose: () => void }) {
  const [businessName, setBusinessName] = useState("");
  const [contactName, setContactName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [cm, setCm] = useState("");
  const [sendDemo, setSendDemo] = useState(true);
  const [copied, setCopied] = useState(false);

  const selectedCM = mockTeam.find(t => t.id === cm);
  const profileSlug = businessName.trim().toLowerCase().replace(/[^a-zåäö0-9]+/g, "-").replace(/-+$/, "");
  const profileUrl = profileSlug ? `https://letrend.se/demo/${profileSlug}` : "";

  const handleCopyLink = () => {
    if (profileUrl) {
      navigator.clipboard.writeText(profileUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-foreground/20 backdrop-blur-sm" onClick={onClose} />

      {/* Modal */}
      <div className="relative bg-card rounded-xl border border-border shadow-lg w-full max-w-lg p-6">
        <div className="flex items-center justify-between mb-5">
          <h2 className="text-lg font-bold font-heading text-foreground">Bjud in ny kund</h2>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground transition-colors">
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[11px] text-muted-foreground uppercase tracking-wider mb-1 block">Företagsnamn *</label>
              <input
                value={businessName}
                onChange={(e) => setBusinessName(e.target.value)}
                className="w-full px-3 py-2.5 rounded-md border border-border bg-background text-sm text-foreground outline-none focus:border-primary/40"
                placeholder="Café Rosé"
              />
            </div>
            <div>
              <label className="text-[11px] text-muted-foreground uppercase tracking-wider mb-1 block">Kontaktperson</label>
              <input
                value={contactName}
                onChange={(e) => setContactName(e.target.value)}
                className="w-full px-3 py-2.5 rounded-md border border-border bg-background text-sm text-foreground outline-none focus:border-primary/40"
                placeholder="Maria Holm"
              />
            </div>
          </div>

          <div>
            <label className="text-[11px] text-muted-foreground uppercase tracking-wider mb-1 block">E-post *</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-3 py-2.5 rounded-md border border-border bg-background text-sm text-foreground outline-none focus:border-primary/40"
              placeholder="info@caferose.se"
            />
          </div>

          <div>
            <label className="text-[11px] text-muted-foreground uppercase tracking-wider mb-1 block">Telefon</label>
            <input
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="w-full px-3 py-2.5 rounded-md border border-border bg-background text-sm text-foreground outline-none focus:border-primary/40"
              placeholder="070-123 45 67"
            />
          </div>

          <div>
            <label className="text-[11px] text-muted-foreground uppercase tracking-wider mb-1 block">Tilldela CM</label>
            <select
              value={cm}
              onChange={(e) => setCm(e.target.value)}
              className="w-full px-3 py-2.5 rounded-md border border-border bg-background text-sm text-foreground outline-none focus:border-primary/40"
            >
              <option value="">Ingen CM än</option>
              {mockTeam.map(t => (
                <option key={t.id} value={t.id}>{t.name}</option>
              ))}
            </select>
          </div>

          {/* Profile link preview */}
          {profileUrl && (
            <div className="p-3 rounded-lg bg-secondary/50 border border-border">
              <label className="text-[11px] text-muted-foreground uppercase tracking-wider mb-2 block">Profillänk (demo-preview)</label>
              <div className="flex items-center gap-2">
                <Link className="h-4 w-4 text-muted-foreground shrink-0" />
                <span className="text-sm text-foreground truncate flex-1 font-mono">{profileUrl}</span>
                <button
                  type="button"
                  onClick={handleCopyLink}
                  className="shrink-0 px-2 py-1 rounded text-xs font-medium bg-card border border-border hover:bg-accent/30 transition-colors flex items-center gap-1"
                >
                  <Copy className="h-3 w-3" />
                  {copied ? "Kopierad!" : "Kopiera"}
                </button>
              </div>
              {selectedCM && (
                <p className="text-xs text-muted-foreground mt-1.5">
                  CM: {selectedCM.name} kopplas till profilen
                </p>
              )}
            </div>
          )}

          <div className="flex items-center gap-3 p-3 rounded-lg bg-secondary/50 border border-border">
            <input
              type="checkbox"
              checked={sendDemo}
              onChange={(e) => setSendDemo(e.target.checked)}
              className="rounded border-border"
              id="send-demo"
            />
            <label htmlFor="send-demo" className="text-sm text-foreground cursor-pointer">
              Skicka demo-preview
              <span className="block text-xs text-muted-foreground">
                Kunden får länken till profilen med prototypdata
              </span>
            </label>
          </div>
        </div>

        <div className="flex gap-3 mt-6">
          <button
            className="flex-1 px-4 py-2.5 rounded-md bg-primary text-primary-foreground text-sm font-semibold hover:bg-primary/90 transition-colors flex items-center justify-center gap-1.5"
          >
            <Check className="h-4 w-4" /> Skicka inbjudan
          </button>
          <button
            onClick={onClose}
            className="px-4 py-2.5 rounded-md border border-border text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            Avbryt
          </button>
        </div>
      </div>
    </div>
  );
}
