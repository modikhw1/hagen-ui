import { useState, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import {
  mockTeam,
  mockCosts,
  mockCustomers,
  mockInvoices,
  getStats,
  getCMActivityStats,
  getCustomersByCM,
  getTotalCost30d,
  getGrowth30d,
  getCMHoverData,
} from "@/data/mock-admin";
import {
  DollarSign,
  UserCheck,
  Send,
  TrendingUp,
  ChevronDown,
  ChevronUp,
  Filter,
} from "lucide-react";
import {
  HoverCard,
  HoverCardContent,
  HoverCardTrigger,
} from "@/components/ui/hover-card";

function timeAgo(dateStr: string): string {
  const now = new Date("2026-04-15T12:00:00Z");
  const date = new Date(dateStr);
  const diffMs = now.getTime() - date.getTime();
  const hours = Math.floor(diffMs / (1000 * 60 * 60));
  if (hours < 1) return "just nu";
  if (hours < 24) return `${hours}h sedan`;
  const days = Math.floor(hours / 24);
  return `${days}d sedan`;
}

function FrequencyBar({ count, max }: { count: number; max: number }) {
  const pct = Math.min(100, (count / max) * 100);
  return (
    <div className="h-1.5 w-16 bg-accent rounded-full overflow-hidden">
      <div
        className="h-full bg-primary rounded-full transition-all"
        style={{ width: `${pct}%` }}
      />
    </div>
  );
}

function TempoIndicator({ actual, expected }: { actual: number; expected: number }) {
  if (expected === 0) return <span className="text-[10px] text-muted-foreground">—</span>;
  const ratio = actual / expected;
  let color = "text-success";
  let label = "I fas";
  if (ratio < 0.5) { color = "text-destructive"; label = "Släpar"; }
  else if (ratio < 0.9) { color = "text-warning"; label = "Något efter"; }
  return (
    <span className={`text-[10px] font-medium ${color}`}>{label}</span>
  );
}

export default function Overview() {
  const navigate = useNavigate();
  const stats = getStats();
  const totalCost = getTotalCost30d();
  const growth = getGrowth30d();
  const [cmExpanded, setCmExpanded] = useState(false);
  const [sortByActivity, setSortByActivity] = useState(false);

  const CM_PREVIEW_COUNT = 5;

  const maxActivity = Math.max(
    ...mockTeam.map((cm) => getCMActivityStats(cm.id).count7d),
    1
  );

  // Sort CMs: optionally by least activity first
  const sortedCMs = useMemo(() => {
    const cms = mockTeam.map((cm) => ({
      ...cm,
      activityStats: getCMActivityStats(cm.id),
      customers: getCustomersByCM(cm.id),
      hoverData: getCMHoverData(cm.id),
    }));
    if (sortByActivity) {
      cms.sort((a, b) => a.activityStats.count7d - b.activityStats.count7d);
    }
    return cms;
  }, [sortByActivity]);

  const visibleCMs = cmExpanded ? sortedCMs : sortedCMs.slice(0, CM_PREVIEW_COUNT);
  const hasMoreCMs = sortedCMs.length > CM_PREVIEW_COUNT;

  const unpaidInvoices = mockInvoices.filter((i) => i.status === "open");
  const demosSent = 4;
  const demosConverted = 1;

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-bold font-heading text-foreground">
          Översikt
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          Operativt tillstånd
        </p>
      </div>

      {/* Key metrics */}
      <section className="mb-8">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          <MetricCard
            icon={<DollarSign className="h-4 w-4" />}
            label="MRR"
            value={`${stats.mrr.toLocaleString("sv-SE")} kr`}
            badge={growth.count > 0 ? `+${growth.count} / +${growth.mrr.toLocaleString("sv-SE")} kr` : undefined}
            badgeLabel="30d"
          />
          <MetricCard
            icon={<UserCheck className="h-4 w-4" />}
            label="Aktiva kunder"
            value={String(stats.activeCount)}
          />
          <MetricCard
            icon={<Send className="h-4 w-4" />}
            label="Demos skickade"
            value={`${demosSent}`}
            sub={`${demosConverted} konverterade`}
          />
          <MetricCard
            icon={<TrendingUp className="h-4 w-4" />}
            label="Kostnad 30d"
            value={`${totalCost.toFixed(0)} kr`}
          />
        </div>
      </section>

      {/* CM Activity Pulse */}
      <section className="mb-8">
        <div className="flex items-baseline gap-3 mb-3">
          <h2 className="text-sm font-semibold text-foreground">CM-aktivitet</h2>
          <span className="text-xs text-muted-foreground">Senaste 7 dagarna</span>
          <div className="flex-1" />
          <button
            onClick={() => setSortByActivity(!sortByActivity)}
            className={`flex items-center gap-1 text-[11px] font-medium transition-colors ${sortByActivity ? "text-primary" : "text-muted-foreground hover:text-foreground"}`}
          >
            <Filter className="h-3 w-3" />
            {sortByActivity ? "Lägst aktivitet först" : "Sortera"}
          </button>
        </div>
        <div className="space-y-2">
          {visibleCMs.map((cm) => {
            // Tempo calc: expected concepts per week based on customer schedules
            const expectedPerWeek = cm.customers.reduce((sum, c) => sum + (c.upload_schedule?.length || 0), 0);
            const actualConcepts = cm.hoverData.planned_clips;

            return (
              <HoverCard key={cm.id} openDelay={200} closeDelay={100}>
                <HoverCardTrigger asChild>
                  <div className="flex items-center gap-4 p-4 bg-card rounded-lg border border-border cursor-pointer hover:bg-accent/20 transition-colors">
                    <div
                      className="w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold text-primary-foreground shrink-0"
                      style={{ backgroundColor: cm.color }}
                    >
                      {cm.name.charAt(0)}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-semibold text-foreground">
                        {cm.name}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {cm.customers.length} kunder · Senast {cm.activityStats.latest ? timeAgo(cm.activityStats.latest) : "ingen"}
                      </div>
                    </div>

                    <div className="shrink-0 flex items-center gap-4">
                      <TempoIndicator actual={actualConcepts} expected={expectedPerWeek} />
                      <div className="flex flex-col items-end gap-1">
                        <FrequencyBar count={cm.activityStats.count7d} max={maxActivity} />
                        <div className="text-[11px] text-muted-foreground">
                          {cm.activityStats.count7d} händelser
                        </div>
                      </div>
                    </div>
                  </div>
                </HoverCardTrigger>
                <HoverCardContent side="right" align="start" sideOffset={8} className="w-72 p-4">
                  <div className="space-y-3">
                    <div className="text-sm font-semibold text-foreground">{cm.name}</div>
                    <div className="space-y-2 text-xs">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Koncept tillagda (7d)</span>
                        <span className="font-medium text-foreground">{cm.hoverData.planned_clips}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Förväntat tempo (7d)</span>
                        <span className="font-medium text-foreground">{expectedPerWeek} koncept</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Senaste koncept</span>
                        <span className="font-medium text-foreground">
                          {cm.hoverData.last_concept_added ? timeAgo(cm.hoverData.last_concept_added) : "—"}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Förväntade idag</span>
                        <span className="font-medium text-foreground">{cm.hoverData.expected_events_today} uploads</span>
                      </div>
                    </div>
                    {cm.hoverData.customers_last_upload.length > 0 && (
                      <div className="border-t border-border pt-2">
                        <div className="text-[11px] text-muted-foreground uppercase tracking-wider mb-1.5">Senaste kunduppladdning</div>
                        {cm.hoverData.customers_last_upload.map((cu) => (
                          <div key={cu.name} className="flex justify-between text-xs py-0.5">
                            <span className="text-foreground">{cu.name}</span>
                            <span className="text-muted-foreground">
                              {cu.date ? timeAgo(cu.date) : "aldrig"}
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </HoverCardContent>
              </HoverCard>
            );
          })}
        </div>

        {hasMoreCMs && (
          <button
            onClick={() => setCmExpanded(!cmExpanded)}
            className="mt-2 w-full flex items-center justify-center gap-1.5 py-2 text-xs font-medium text-muted-foreground hover:text-foreground transition-colors"
          >
            {cmExpanded ? (
              <>Visa färre <ChevronUp className="h-3 w-3" /></>
            ) : (
              <>Visa alla {sortedCMs.length} CMs <ChevronDown className="h-3 w-3" /></>
            )}
          </button>
        )}
      </section>

      {/* Requires attention */}
      {unpaidInvoices.length > 0 && (
        <section className="mb-8">
          <SectionHeader title="Kräver uppmärksamhet" />
          <div className="space-y-2">
            {unpaidInvoices.map((inv) => (
              <div
                key={inv.id}
                className="flex items-center justify-between px-4 py-3 rounded-lg border border-warning/30 bg-warning/5 cursor-pointer hover:bg-warning/10 transition-colors"
                onClick={() => navigate(`/admin/customers/${inv.customer_id}`)}
              >
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 rounded-full bg-warning shrink-0" />
                  <div>
                    <span className="text-sm font-medium text-foreground">
                      {inv.customer_name}
                    </span>
                    <span className="text-sm text-muted-foreground ml-2">
                      Obetald faktura ·{" "}
                      {(inv.amount_due / 100).toLocaleString("sv-SE")} kr
                    </span>
                  </div>
                </div>
                <span className="text-xs text-muted-foreground">
                  Förfaller{" "}
                  {inv.due_date
                    ? new Date(inv.due_date).toLocaleDateString("sv-SE", {
                        day: "numeric",
                        month: "short",
                      })
                    : "—"}
                </span>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Cost overview - card grid */}
      <section className="mb-8">
        <SectionHeader title="Kostnader" subtitle="30 dagar" />
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-3">
          {mockCosts.map((cost) => (
            <div
              key={cost.service}
              className="flex flex-col justify-between p-4 bg-card rounded-lg border border-border"
            >
              <div className="text-xs text-muted-foreground mb-2">{cost.service}</div>
              <div className="text-base font-bold text-foreground">
                {cost.cost_30d > 0 ? `${cost.cost_30d.toFixed(0)} kr` : "Gratis"}
              </div>
              <div className="text-[11px] text-muted-foreground mt-1">
                {cost.calls_30d.toLocaleString()} anrop
              </div>
            </div>
          ))}
          <div className="flex flex-col justify-center p-4 bg-secondary/50 rounded-lg border border-border">
            <div className="text-xs text-muted-foreground mb-2">Totalt</div>
            <div className="text-base font-bold text-foreground">
              {totalCost.toFixed(0)} kr
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

function SectionHeader({
  title,
  subtitle,
}: {
  title: string;
  subtitle?: string;
}) {
  return (
    <div className="flex items-baseline gap-3 mb-3">
      <h2 className="text-sm font-semibold text-foreground">{title}</h2>
      {subtitle && (
        <span className="text-xs text-muted-foreground">{subtitle}</span>
      )}
    </div>
  );
}

function MetricCard({
  icon,
  label,
  value,
  sub,
  badge,
  badgeLabel,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  sub?: string;
  badge?: string;
  badgeLabel?: string;
}) {
  return (
    <div className="flex items-center gap-3 px-4 py-4 bg-card rounded-lg border border-border">
      <div className="text-muted-foreground">{icon}</div>
      <div className="flex-1">
        <div className="text-[11px] text-muted-foreground uppercase tracking-wider">
          {label}
        </div>
        <div className="text-base font-bold text-foreground">{value}</div>
        {sub && (
          <div className="text-[11px] text-muted-foreground">{sub}</div>
        )}
      </div>
      {badge && (
        <div className="shrink-0 text-right">
          <div className="text-[11px] font-semibold text-success">{badge}</div>
          {badgeLabel && <div className="text-[10px] text-muted-foreground">{badgeLabel}</div>}
        </div>
      )}
    </div>
  );
}
