import { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { mockCustomers, mockTeam, mockInvoices, mockSubscriptions, mockTikTokStats, mockPendingLineItems, type CustomerProfile } from "@/data/mock-admin";
import { ArrowLeft, TrendingUp, TrendingDown, Minus, Pencil, X, Check, Plus } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";

// Smooth a data series with a simple moving average
function smoothData(data: number[], windowSize: number): number[] {
  const result: number[] = [];
  for (let i = 0; i < data.length; i++) {
    const start = Math.max(0, i - Math.floor(windowSize / 2));
    const end = Math.min(data.length, i + Math.ceil(windowSize / 2));
    const slice = data.slice(start, end);
    result.push(slice.reduce((a, b) => a + b, 0) / slice.length);
  }
  return result;
}

function ChartSVG({ data, smoothed, height = 80, color = "hsl(var(--primary))", smoothColor = "hsl(var(--muted-foreground))" }: {
  data: number[];
  smoothed?: number[];
  height?: number;
  color?: string;
  smoothColor?: string;
}) {
  const w = 400;
  const h = height;
  const allValues = [...data, ...(smoothed || [])];
  const max = Math.max(...allValues, 1);
  const min = Math.min(...allValues);
  const range = max - min || 1;
  const pad = 4;

  const toPoints = (arr: number[]) =>
    arr.map((v, i) => {
      const x = (i / (arr.length - 1)) * w;
      const y = h - ((v - min) / range) * (h - pad * 2) - pad;
      return `${x},${y}`;
    }).join(" ");

  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="w-full" preserveAspectRatio="none">
      {smoothed && (
        <polyline
          points={toPoints(smoothed)}
          fill="none"
          stroke={smoothColor}
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeDasharray="4 3"
          opacity={0.5}
        />
      )}
      <polyline
        points={toPoints(data)}
        fill="none"
        stroke={color}
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export default function CustomerDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const customer = mockCustomers.find((c) => c.id === id);
  const [editingContact, setEditingContact] = useState(false);
  const [editingPricing, setEditingPricing] = useState(false);
  const [pendingItems, setPendingItems] = useState(mockPendingLineItems[id!] || []);
  const [showAddLineItem, setShowAddLineItem] = useState(false);
  const [showDiscountModal, setShowDiscountModal] = useState(false);
  const [showManualInvoice, setShowManualInvoice] = useState(false);
  const [showChangeCM, setShowChangeCM] = useState(false);
  const [selectedInvoice, setSelectedInvoice] = useState<typeof mockInvoices[0] | null>(null);
  const [showSubModal, setShowSubModal] = useState(false);

  if (!customer) {
    return (
      <div className="py-12 text-center text-sm text-muted-foreground">
        Kunden hittades inte.
      </div>
    );
  }

  const cm = mockTeam.find((t) => t.name === customer.account_manager);
  const invoices = mockInvoices.filter((i) => i.customer_id === id);
  const subscription = mockSubscriptions.find((s) => s.customer_id === id);
  const tiktok = mockTikTokStats[id!];

  const statusLabel = (s: string) => {
    switch (s) {
      case "active": case "agreed": return "Aktiv";
      case "invited": return "Inbjuden";
      case "pending": return "Väntande";
      case "archived": return "Arkiverad";
      default: return s;
    }
  };

  const statusClass = (s: string) => {
    if (s === "active" || s === "agreed") return "bg-success/10 text-success";
    if (s === "invited") return "bg-info/10 text-info";
    if (s === "pending") return "bg-warning/10 text-warning";
    return "bg-muted text-muted-foreground";
  };

  const followerSmoothed = tiktok ? smoothData(tiktok.follower_history_30d, 7) : [];
  const viewsSmoothed = tiktok ? smoothData(tiktok.views_history_30d, 7) : [];

  const nextInvoiceBase = customer.monthly_price;
  const extraTotal = pendingItems.reduce((s, item) => s + item.amount * item.quantity, 0);
  const nextInvoiceTotal = nextInvoiceBase * 100 + extraTotal;

  return (
    <div>
      <button
        onClick={() => navigate("/admin/customers")}
        className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground mb-6 transition-colors"
      >
        <ArrowLeft className="h-4 w-4" /> Tillbaka till kunder
      </button>

      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold font-heading text-foreground">
            {customer.business_name}
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            {customer.contact_email}
            {customer.customer_contact_name && ` · ${customer.customer_contact_name}`}
            {customer.tiktok_handle && (
              <span className="ml-2 text-primary">{customer.tiktok_handle}</span>
            )}
          </p>
        </div>
        <span className={`inline-flex px-3 py-1.5 rounded-full text-xs font-semibold ${statusClass(customer.status)}`}>
          {statusLabel(customer.status)}
        </span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left column */}
        <div className="lg:col-span-2 space-y-6">
          {/* TikTok Stats */}
          {tiktok && (
            <Section title="TikTok-statistik">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-5">
                <StatBox label="Följare" value={tiktok.followers.toLocaleString()} delta={tiktok.follower_delta_7d} sub="7d" />
                <StatBox label="Snitt visningar" value={tiktok.avg_views_7d.toLocaleString()} sub="7d" />
                <StatBox label="Engagement" value={`${tiktok.engagement_rate}%`} />
                <StatBox label="Publicerade" value={`${tiktok.videos_last_7d}`} sub="senaste 7d" />
              </div>

              <div className="mb-4">
                <div className="flex items-baseline justify-between mb-2">
                  <div className="text-xs font-semibold text-foreground">Följare (30d)</div>
                  <div className="flex items-center gap-3 text-[10px] text-muted-foreground">
                    <span className="flex items-center gap-1"><span className="w-3 h-0.5 bg-primary inline-block rounded" /> Faktisk</span>
                    <span className="flex items-center gap-1"><span className="w-3 h-0.5 bg-muted-foreground/50 inline-block rounded border-dashed" /> Medel</span>
                  </div>
                </div>
                <div className="bg-secondary/30 rounded-lg p-3">
                  <ChartSVG data={tiktok.follower_history_30d} smoothed={followerSmoothed} height={80} />
                  <div className="flex justify-between text-[10px] text-muted-foreground mt-1">
                    <span>30d sedan</span>
                    <span>Idag</span>
                  </div>
                </div>
              </div>

              <div className="mb-4">
                <div className="flex items-baseline justify-between mb-2">
                  <div className="text-xs font-semibold text-foreground">Visningar (30d)</div>
                </div>
                <div className="bg-secondary/30 rounded-lg p-3">
                  <ChartSVG data={tiktok.views_history_30d} smoothed={viewsSmoothed} height={60} color="hsl(var(--info))" />
                  <div className="flex justify-between text-[10px] text-muted-foreground mt-1">
                    <span>30d sedan</span>
                    <span>Idag</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="p-3 rounded-lg bg-secondary/50">
                  <div className="text-[11px] text-muted-foreground uppercase tracking-wider mb-1">Följartillväxt 30d</div>
                  <div className="flex items-center gap-2">
                    <DeltaIndicator delta={tiktok.follower_delta_30d} />
                    <span className="text-sm text-foreground font-semibold">
                      {tiktok.follower_delta_30d > 0 ? "+" : ""}{tiktok.follower_delta_30d}%
                    </span>
                  </div>
                </div>
                <div className="p-3 rounded-lg bg-secondary/50">
                  <div className="text-[11px] text-muted-foreground uppercase tracking-wider mb-1">Snitt visningar 30d</div>
                  <span className="text-sm text-foreground font-semibold">{tiktok.avg_views_30d.toLocaleString()}</span>
                </div>
              </div>
            </Section>
          )}

          {/* Contract & Pricing */}
          <Section
            title="Avtal & Prissättning"
            action={
              <button
                onClick={() => setEditingPricing(!editingPricing)}
                className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1 transition-colors"
              >
                {editingPricing ? <X className="h-3 w-3" /> : <Pencil className="h-3 w-3" />}
                {editingPricing ? "Avbryt" : "Redigera"}
              </button>
            }
          >
            {editingPricing ? (
              <PricingEditForm customer={customer} onClose={() => setEditingPricing(false)} />
            ) : (
              <div className="grid grid-cols-2 gap-4">
                <Field label="Månadspris" value={customer.monthly_price > 0 ? `${customer.monthly_price.toLocaleString()} kr` : "Ej satt"} />
                <Field label="Intervall" value={customer.subscription_interval === "month" ? "Månadsvis" : customer.subscription_interval === "quarter" ? "Kvartalsvis" : "Årsvis"} />
                <Field label="Nästa faktura" value={customer.next_invoice_date ? new Date(customer.next_invoice_date).toLocaleDateString("sv-SE") : "—"} />
                <Field label="Kund sedan" value={new Date(customer.created_at).toLocaleDateString("sv-SE")} />
                {customer.discount_type && customer.discount_type !== "none" && (
                  <Field label="Rabatt" value={
                    customer.discount_type === "percent" ? `${customer.discount_value}%`
                      : customer.discount_type === "amount" ? `${customer.discount_value} kr`
                        : `${customer.discount_value} gratis månader`
                  } />
                )}
              </div>
            )}
          </Section>

          {/* Next invoice preview */}
          {customer.next_invoice_date && customer.monthly_price > 0 && (
            <Section
              title="Nästkommande faktura"
              action={
                <span className="text-xs text-muted-foreground">
                  {new Date(customer.next_invoice_date).toLocaleDateString("sv-SE")}
                </span>
              }
            >
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-foreground">Månadsabonnemang</span>
                  <span className="font-medium text-foreground">{customer.monthly_price.toLocaleString()} kr</span>
                </div>
                {pendingItems.map((item, idx) => (
                  <div key={idx} className="flex justify-between text-sm">
                    <span className="text-foreground">{item.description}</span>
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-foreground">{(item.amount / 100).toLocaleString()} kr</span>
                      <button
                        onClick={() => setPendingItems(pendingItems.filter((_, i) => i !== idx))}
                        className="text-muted-foreground hover:text-destructive transition-colors"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </div>
                  </div>
                ))}
                <div className="border-t border-border pt-2 flex justify-between text-sm font-semibold">
                  <span className="text-foreground">Totalt</span>
                  <span className="text-foreground">{(nextInvoiceTotal / 100).toLocaleString("sv-SE")} kr</span>
                </div>
              </div>

              {showAddLineItem ? (
                <AddLineItemForm
                  onAdd={(item) => {
                    setPendingItems([...pendingItems, item]);
                    setShowAddLineItem(false);
                  }}
                  onClose={() => setShowAddLineItem(false)}
                />
              ) : (
                <button
                  onClick={() => setShowAddLineItem(true)}
                  className="mt-3 text-xs text-primary hover:text-primary/80 font-medium transition-colors flex items-center gap-1"
                >
                  <Plus className="h-3 w-3" /> Lägg till rad
                </button>
              )}
            </Section>
          )}

          {/* Invoice history */}
          <Section title="Fakturahistorik">
            {invoices.length === 0 ? (
              <p className="text-sm text-muted-foreground">Inga fakturor ännu.</p>
            ) : (
              <div className="space-y-3">
                {invoices.map((inv) => (
                  <div key={inv.id} className="rounded-lg border border-border overflow-hidden cursor-pointer hover:border-primary/30 transition-colors" onClick={() => setSelectedInvoice(inv)}>
                    <div className="flex items-center justify-between px-4 py-3">
                      <div className="flex items-center gap-3">
                        <span className="text-sm font-medium text-foreground">
                          {(inv.amount_due / 100).toLocaleString("sv-SE")} kr
                        </span>
                        <span className="text-xs text-muted-foreground">
                          {new Date(inv.created_at).toLocaleDateString("sv-SE")}
                        </span>
                      </div>
                      <span className={`text-xs font-semibold px-2 py-1 rounded-full ${
                        inv.status === "paid" ? "bg-success/10 text-success"
                          : inv.status === "open" ? "bg-warning/10 text-warning"
                            : "bg-muted text-muted-foreground"
                      }`}>
                        {inv.status === "paid" ? "Betald" : inv.status === "open" ? "Öppen" : inv.status}
                      </span>
                    </div>
                    {inv.line_items && inv.line_items.length > 0 && (
                      <div className="border-t border-border bg-secondary/30 px-4 py-2">
                        {inv.line_items.map((item, idx) => (
                          <div key={idx} className="flex justify-between py-1 text-xs">
                            <span className="text-muted-foreground">{item.description}</span>
                            <span className="text-foreground font-medium">
                              {(item.amount / 100).toLocaleString("sv-SE")} kr
                            </span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </Section>
        </div>

        {/* Right column */}
        <div className="space-y-6">
          <Section title="Content Manager">
            {cm ? (
              <div className="flex items-center gap-3">
                <div
                  className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold text-primary-foreground"
                  style={{ backgroundColor: cm.color }}
                >
                  {cm.name.charAt(0)}
                </div>
                <div>
                  <div className="text-sm font-semibold text-foreground">{cm.name}</div>
                  <div className="text-xs text-muted-foreground">{cm.email}</div>
                </div>
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">Ingen CM tilldelad</p>
            )}
          </Section>

          <Section
            title="Kontaktuppgifter"
            action={
              <button
                onClick={() => setEditingContact(!editingContact)}
                className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1 transition-colors"
              >
                {editingContact ? <X className="h-3 w-3" /> : <Pencil className="h-3 w-3" />}
                {editingContact ? "Avbryt" : "Redigera"}
              </button>
            }
          >
            {editingContact ? (
              <ContactEditForm customer={customer} onClose={() => setEditingContact(false)} />
            ) : (
              <div className="space-y-3">
                <Field label="E-post" value={customer.contact_email} />
                <Field label="Kontaktperson" value={customer.customer_contact_name || "—"} />
                <Field label="Telefon" value={customer.phone || "—"} />
              </div>
            )}
          </Section>

          <Section title="Åtgärder">
            <div className="space-y-2">
              <button
                onClick={() => setShowChangeCM(true)}
                className="w-full px-4 py-2 rounded-md border border-border text-sm font-medium text-foreground hover:bg-accent transition-colors text-left"
              >
                Ändra Content Manager
              </button>
              <button
                onClick={() => setShowDiscountModal(true)}
                className="w-full px-4 py-2 rounded-md border border-border text-sm font-medium text-foreground hover:bg-accent transition-colors text-left"
              >
                Hantera rabatt
              </button>
               <button
                 onClick={() => setShowManualInvoice(true)}
                 className="w-full px-4 py-2 rounded-md border border-border text-sm font-medium text-foreground hover:bg-accent transition-colors text-left"
               >
                 Skapa manuell faktura
               </button>
               {subscription && (
                 <button
                   onClick={() => setShowSubModal(true)}
                   className="w-full px-4 py-2 rounded-md border border-border text-sm font-medium text-foreground hover:bg-accent transition-colors text-left"
                 >
                   Hantera abonnemang
                 </button>
               )}
               {customer.status !== "archived" && (
                 <button className="w-full px-4 py-2 rounded-md border border-destructive/30 text-sm font-medium text-destructive hover:bg-destructive/5 transition-colors text-left">
                   Arkivera kund
                 </button>
               )}
            </div>
          </Section>
        </div>
      </div>

      {/* Modals */}
      {showDiscountModal && (
        <DiscountModal customer={customer} onClose={() => setShowDiscountModal(false)} />
      )}
      {showManualInvoice && (
        <ManualInvoiceModal customer={customer} onClose={() => setShowManualInvoice(false)} />
      )}
      {showChangeCM && (
        <ChangeCMModal customer={customer} onClose={() => setShowChangeCM(false)} />
      )}
      {selectedInvoice && (
        <InvoiceDetailModal invoice={selectedInvoice} onClose={() => setSelectedInvoice(null)} />
      )}
      {showSubModal && subscription && (
        <SubscriptionModal subscription={subscription} customerName={customer.business_name} onClose={() => setShowSubModal(false)} />
      )}
    </div>
  );
}

// ---- Modals ----

function DiscountModal({ customer, onClose }: { customer: CustomerProfile; onClose: () => void }) {
  const [type, setType] = useState<string>(customer.discount_type || "none");
  const [value, setValue] = useState(String(customer.discount_value || ""));

  return (
    <Dialog open onOpenChange={(open) => { if (!open) onClose(); }}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Hantera rabatt</DialogTitle>
          <DialogDescription>{customer.business_name}</DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <div className="text-[11px] text-muted-foreground uppercase tracking-wider mb-1">Rabattyp</div>
            <select
              value={type}
              onChange={(e) => setType(e.target.value)}
              className="w-full px-3 py-2 rounded-md border border-border bg-card text-sm text-foreground outline-none focus:border-primary/30"
            >
              <option value="none">Ingen rabatt</option>
              <option value="percent">Procent</option>
              <option value="amount">Fast belopp (kr)</option>
              <option value="free_months">Gratis månader</option>
            </select>
          </div>
          {type !== "none" && (
            <EditField
              label={type === "percent" ? "Procent (%)" : type === "amount" ? "Belopp (kr)" : "Antal månader"}
              value={value}
              onChange={setValue}
              type="number"
              placeholder={type === "percent" ? "10" : type === "amount" ? "500" : "1"}
            />
          )}
          {type !== "none" && customer.monthly_price > 0 && value && (
            <div className="p-3 rounded-lg bg-secondary/50">
              <div className="text-[11px] text-muted-foreground uppercase tracking-wider mb-1">Förhandsgranskning</div>
              <div className="text-sm text-foreground">
                {type === "percent" && `Nytt pris: ${Math.round(customer.monthly_price * (1 - Number(value) / 100)).toLocaleString()} kr/mån`}
                {type === "amount" && `Nytt pris: ${(customer.monthly_price - Number(value)).toLocaleString()} kr/mån`}
                {type === "free_months" && `${value} gratis månader, sedan ${customer.monthly_price.toLocaleString()} kr/mån`}
              </div>
            </div>
          )}
          <div className="flex gap-2 pt-2">
            <button onClick={onClose} className="flex-1 px-4 py-2 rounded-md bg-primary text-primary-foreground text-sm font-semibold hover:bg-primary/90 transition-colors flex items-center justify-center gap-1.5">
              <Check className="h-3.5 w-3.5" /> Spara
            </button>
            <button onClick={onClose} className="px-4 py-2 rounded-md border border-border text-sm text-muted-foreground hover:text-foreground transition-colors">
              Avbryt
            </button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function ManualInvoiceModal({ customer, onClose }: { customer: CustomerProfile; onClose: () => void }) {
  const [items, setItems] = useState<{ description: string; amount: string }[]>([
    { description: "", amount: "" },
  ]);
  const [memo, setMemo] = useState("");

  const addRow = () => setItems([...items, { description: "", amount: "" }]);
  const removeRow = (idx: number) => setItems(items.filter((_, i) => i !== idx));
  const updateRow = (idx: number, field: "description" | "amount", val: string) => {
    const next = [...items];
    next[idx] = { ...next[idx], [field]: val };
    setItems(next);
  };

  const total = items.reduce((s, i) => s + (Number(i.amount) || 0), 0);

  return (
    <Dialog open onOpenChange={(open) => { if (!open) onClose(); }}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Skapa manuell faktura</DialogTitle>
          <DialogDescription>{customer.business_name}</DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            {items.map((item, idx) => (
              <div key={idx} className="flex gap-2 items-end">
                <div className="flex-1">
                  {idx === 0 && <div className="text-[11px] text-muted-foreground uppercase tracking-wider mb-1">Beskrivning</div>}
                  <input
                    value={item.description}
                    onChange={(e) => updateRow(idx, "description", e.target.value)}
                    placeholder="t.ex. Inspelningshjälp"
                    className="w-full px-3 py-2 rounded-md border border-border bg-card text-sm text-foreground outline-none focus:border-primary/30"
                  />
                </div>
                <div className="w-28">
                  {idx === 0 && <div className="text-[11px] text-muted-foreground uppercase tracking-wider mb-1">Belopp (kr)</div>}
                  <input
                    type="number"
                    value={item.amount}
                    onChange={(e) => updateRow(idx, "amount", e.target.value)}
                    placeholder="500"
                    className="w-full px-3 py-2 rounded-md border border-border bg-card text-sm text-foreground outline-none focus:border-primary/30"
                  />
                </div>
                {items.length > 1 && (
                  <button onClick={() => removeRow(idx)} className="pb-2 text-muted-foreground hover:text-destructive transition-colors">
                    <X className="h-4 w-4" />
                  </button>
                )}
              </div>
            ))}
          </div>
          <button onClick={addRow} className="text-xs text-primary hover:text-primary/80 font-medium transition-colors flex items-center gap-1">
            <Plus className="h-3 w-3" /> Lägg till rad
          </button>

          <div>
            <div className="text-[11px] text-muted-foreground uppercase tracking-wider mb-1">Memo (valfritt)</div>
            <textarea
              value={memo}
              onChange={(e) => setMemo(e.target.value)}
              rows={2}
              placeholder="Intern anteckning eller meddelande till kund"
              className="w-full px-3 py-2 rounded-md border border-border bg-card text-sm text-foreground outline-none focus:border-primary/30 resize-none"
            />
          </div>

          {total > 0 && (
            <div className="flex justify-between text-sm font-semibold p-3 rounded-lg bg-secondary/50">
              <span className="text-foreground">Totalt</span>
              <span className="text-foreground">{total.toLocaleString()} kr</span>
            </div>
          )}

          <div className="flex gap-2 pt-2">
            <button onClick={onClose} className="flex-1 px-4 py-2 rounded-md bg-primary text-primary-foreground text-sm font-semibold hover:bg-primary/90 transition-colors flex items-center justify-center gap-1.5">
              <Check className="h-3.5 w-3.5" /> Skapa faktura
            </button>
            <button onClick={onClose} className="px-4 py-2 rounded-md border border-border text-sm text-muted-foreground hover:text-foreground transition-colors">
              Avbryt
            </button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function ChangeCMModal({ customer, onClose }: { customer: CustomerProfile; onClose: () => void }) {
  const [selectedCM, setSelectedCM] = useState(customer.account_manager_profile_id || "");

  return (
    <Dialog open onOpenChange={(open) => { if (!open) onClose(); }}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Ändra Content Manager</DialogTitle>
          <DialogDescription>{customer.business_name}</DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="text-xs text-muted-foreground mb-2">
            Nuvarande: <span className="font-medium text-foreground">{customer.account_manager || "Ingen"}</span>
          </div>
          <div className="space-y-2">
            {mockTeam.filter(t => t.is_active).map((cm) => (
              <label
                key={cm.id}
                className={`flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-colors ${
                  selectedCM === cm.id ? "border-primary bg-primary/5" : "border-border hover:bg-accent/30"
                }`}
              >
                <input
                  type="radio"
                  name="cm"
                  value={cm.id}
                  checked={selectedCM === cm.id}
                  onChange={() => setSelectedCM(cm.id)}
                  className="sr-only"
                />
                <div
                  className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold text-primary-foreground shrink-0"
                  style={{ backgroundColor: cm.color }}
                >
                  {cm.name.charAt(0)}
                </div>
                <div>
                  <div className="text-sm font-semibold text-foreground">{cm.name}</div>
                  <div className="text-xs text-muted-foreground">{cm.city || cm.email}</div>
                </div>
              </label>
            ))}
          </div>
          <div className="flex gap-2 pt-2">
            <button onClick={onClose} className="flex-1 px-4 py-2 rounded-md bg-primary text-primary-foreground text-sm font-semibold hover:bg-primary/90 transition-colors flex items-center justify-center gap-1.5">
              <Check className="h-3.5 w-3.5" /> Spara
            </button>
            <button onClick={onClose} className="px-4 py-2 rounded-md border border-border text-sm text-muted-foreground hover:text-foreground transition-colors">
              Avbryt
            </button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function InvoiceDetailModal({ invoice, onClose }: { invoice: import("@/data/mock-admin").InvoiceSummary; onClose: () => void }) {
  const statusLabel = (s: string) => {
    switch (s) {
      case "paid": return "Betald";
      case "open": return "Öppen";
      case "void": return "Annullerad";
      case "draft": return "Utkast";
      default: return s;
    }
  };
  const statusClass = (s: string) => {
    switch (s) {
      case "paid": return "bg-success/10 text-success";
      case "open": return "bg-warning/10 text-warning";
      case "void": return "bg-muted text-muted-foreground";
      case "draft": return "bg-info/10 text-info";
      default: return "bg-muted text-muted-foreground";
    }
  };

  return (
    <Dialog open onOpenChange={(open) => { if (!open) onClose(); }}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Fakturadetaljer</DialogTitle>
          <DialogDescription>{invoice.customer_name}</DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-lg font-bold text-foreground">{(invoice.amount_due / 100).toLocaleString("sv-SE")} kr</span>
            <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${statusClass(invoice.status)}`}>
              {statusLabel(invoice.status)}
            </span>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <div className="text-[11px] text-muted-foreground uppercase tracking-wider mb-0.5">Skapad</div>
              <div className="text-sm text-foreground">{new Date(invoice.created_at).toLocaleDateString("sv-SE")}</div>
            </div>
            {invoice.due_date && (
              <div>
                <div className="text-[11px] text-muted-foreground uppercase tracking-wider mb-0.5">Förfallodatum</div>
                <div className="text-sm text-foreground">{new Date(invoice.due_date).toLocaleDateString("sv-SE")}</div>
              </div>
            )}
            <div>
              <div className="text-[11px] text-muted-foreground uppercase tracking-wider mb-0.5">Faktura-ID</div>
              <div className="text-sm text-muted-foreground font-mono">{invoice.id}</div>
            </div>
          </div>

          {invoice.line_items && invoice.line_items.length > 0 && (
            <div>
              <div className="text-[11px] text-muted-foreground uppercase tracking-wider mb-2">Rader</div>
              <div className="rounded-lg border border-border overflow-hidden">
                {invoice.line_items.map((item, idx) => (
                  <div key={idx} className={`flex justify-between px-4 py-2.5 text-sm ${idx < invoice.line_items!.length - 1 ? "border-b border-border" : ""}`}>
                    <span className="text-foreground">{item.description}</span>
                    <span className="font-medium text-foreground">{(item.amount / 100).toLocaleString("sv-SE")} kr</span>
                  </div>
                ))}
                <div className="flex justify-between px-4 py-2.5 text-sm font-semibold bg-secondary/50 border-t border-border">
                  <span className="text-foreground">Totalt</span>
                  <span className="text-foreground">{(invoice.amount_due / 100).toLocaleString("sv-SE")} kr</span>
                </div>
              </div>
            </div>
          )}

          {invoice.status === "open" && (
            <div className="flex gap-2 pt-2">
              <button onClick={onClose} className="flex-1 px-4 py-2 rounded-md bg-primary text-primary-foreground text-sm font-semibold hover:bg-primary/90 transition-colors">
                Markera som betald
              </button>
              <button onClick={onClose} className="px-4 py-2 rounded-md border border-destructive/30 text-sm font-medium text-destructive hover:bg-destructive/5 transition-colors">
                Annullera
              </button>
            </div>
          )}
          {invoice.status !== "open" && (
            <div className="flex justify-end pt-2">
              <button onClick={onClose} className="px-4 py-2 rounded-md border border-border text-sm text-muted-foreground hover:text-foreground transition-colors">
                Stäng
              </button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

function SubscriptionModal({ subscription, customerName, onClose }: { subscription: import("@/data/mock-admin").SubscriptionSummary; customerName: string; onClose: () => void }) {
  const [action, setAction] = useState<"none" | "cancel_end" | "cancel_now" | "pause">("none");

  const statusLabel = (s: string) => {
    switch (s) {
      case "active": return "Aktivt";
      case "trialing": return "Provperiod";
      case "past_due": return "Förfallet";
      case "canceled": return "Avslutat";
      default: return s;
    }
  };

  const intervalLabel = (i: string) =>
    i === "month" ? "Månadsvis" : i === "quarter" ? "Kvartalsvis" : "Årsvis";

  return (
    <Dialog open onOpenChange={(open) => { if (!open) onClose(); }}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Hantera abonnemang</DialogTitle>
          <DialogDescription>{customerName}</DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <div className="text-[11px] text-muted-foreground uppercase tracking-wider mb-0.5">Status</div>
              <div className="text-sm font-semibold text-foreground">{statusLabel(subscription.status)}</div>
            </div>
            <div>
              <div className="text-[11px] text-muted-foreground uppercase tracking-wider mb-0.5">Belopp</div>
              <div className="text-sm font-semibold text-foreground">{subscription.amount.toLocaleString("sv-SE")} kr/{subscription.interval === "month" ? "mån" : subscription.interval === "quarter" ? "kvartal" : "år"}</div>
            </div>
            <div>
              <div className="text-[11px] text-muted-foreground uppercase tracking-wider mb-0.5">Intervall</div>
              <div className="text-sm text-foreground">{intervalLabel(subscription.interval)}</div>
            </div>
            {subscription.current_period_end && (
              <div>
                <div className="text-[11px] text-muted-foreground uppercase tracking-wider mb-0.5">Period slutar</div>
                <div className="text-sm text-foreground">{new Date(subscription.current_period_end).toLocaleDateString("sv-SE")}</div>
              </div>
            )}
          </div>

          {subscription.cancel_at_period_end && (
            <div className="p-3 rounded-lg bg-warning/10 text-sm text-warning font-medium">
              Abonnemanget avslutas vid periodens slut
            </div>
          )}

          <div>
            <div className="text-[11px] text-muted-foreground uppercase tracking-wider mb-2">Åtgärd</div>
            <div className="space-y-2">
              <label className={`flex items-start gap-3 p-3 rounded-lg border cursor-pointer transition-colors ${action === "cancel_end" ? "border-primary bg-primary/5" : "border-border hover:bg-accent/30"}`}>
                <input type="radio" name="sub_action" checked={action === "cancel_end"} onChange={() => setAction("cancel_end")} className="mt-0.5" />
                <div>
                  <div className="text-sm font-medium text-foreground">Avsluta vid periodens slut</div>
                  <div className="text-xs text-muted-foreground">Kunden behåller tillgång till periodens slut</div>
                </div>
              </label>
              <label className={`flex items-start gap-3 p-3 rounded-lg border cursor-pointer transition-colors ${action === "cancel_now" ? "border-destructive bg-destructive/5" : "border-border hover:bg-accent/30"}`}>
                <input type="radio" name="sub_action" checked={action === "cancel_now"} onChange={() => setAction("cancel_now")} className="mt-0.5" />
                <div>
                  <div className="text-sm font-medium text-foreground">Avsluta omedelbart</div>
                  <div className="text-xs text-muted-foreground">Avslutar direkt, ingen återbetalning</div>
                </div>
              </label>
              <label className={`flex items-start gap-3 p-3 rounded-lg border cursor-pointer transition-colors ${action === "pause" ? "border-primary bg-primary/5" : "border-border hover:bg-accent/30"}`}>
                <input type="radio" name="sub_action" checked={action === "pause"} onChange={() => setAction("pause")} className="mt-0.5" />
                <div>
                  <div className="text-sm font-medium text-foreground">Pausa abonnemang</div>
                  <div className="text-xs text-muted-foreground">Frys betalningar tills vidare</div>
                </div>
              </label>
            </div>
          </div>

          <div className="flex gap-2 pt-2">
            <button
              onClick={onClose}
              disabled={action === "none"}
              className={`flex-1 px-4 py-2 rounded-md text-sm font-semibold transition-colors flex items-center justify-center gap-1.5 ${
                action === "cancel_now"
                  ? "bg-destructive text-destructive-foreground hover:bg-destructive/90"
                  : action === "none"
                    ? "bg-muted text-muted-foreground cursor-not-allowed"
                    : "bg-primary text-primary-foreground hover:bg-primary/90"
              }`}
            >
              <Check className="h-3.5 w-3.5" />
              {action === "cancel_now" ? "Avsluta nu" : action === "cancel_end" ? "Schemalägg avslut" : action === "pause" ? "Pausa" : "Välj åtgärd"}
            </button>
            <button onClick={onClose} className="px-4 py-2 rounded-md border border-border text-sm text-muted-foreground hover:text-foreground transition-colors">
              Avbryt
            </button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// ---- Sub-components ----

function Section({ title, children, action }: { title: string; children: React.ReactNode; action?: React.ReactNode }) {
  return (
    <div className="bg-card rounded-lg border border-border p-5">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-semibold text-foreground">{title}</h3>
        {action}
      </div>
      {children}
    </div>
  );
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="text-[11px] text-muted-foreground uppercase tracking-wider mb-0.5">{label}</div>
      <div className="text-sm text-foreground">{value}</div>
    </div>
  );
}

function StatBox({ label, value, delta, sub }: { label: string; value: string; delta?: number; sub?: string }) {
  return (
    <div className="p-3 rounded-lg bg-secondary/50">
      <div className="text-[11px] text-muted-foreground uppercase tracking-wider mb-1">{label}</div>
      <div className="flex items-center gap-2">
        <span className="text-base font-bold text-foreground">{value}</span>
        {delta !== undefined && <DeltaIndicator delta={delta} />}
      </div>
      {sub && <div className="text-[10px] text-muted-foreground mt-0.5">{sub}</div>}
    </div>
  );
}

function DeltaIndicator({ delta }: { delta: number }) {
  if (delta > 0) return <TrendingUp className="h-3.5 w-3.5 text-success" />;
  if (delta < 0) return <TrendingDown className="h-3.5 w-3.5 text-destructive" />;
  return <Minus className="h-3.5 w-3.5 text-muted-foreground" />;
}

function ContactEditForm({ customer, onClose }: { customer: CustomerProfile; onClose: () => void }) {
  const [name, setName] = useState(customer.customer_contact_name || "");
  const [email, setEmail] = useState(customer.contact_email);
  const [phone, setPhone] = useState(customer.phone || "");

  return (
    <div className="space-y-3">
      <EditField label="E-post" value={email} onChange={setEmail} />
      <EditField label="Kontaktperson" value={name} onChange={setName} />
      <EditField label="Telefon" value={phone} onChange={setPhone} />
      <div className="flex gap-2 pt-2">
        <button onClick={onClose} className="flex-1 px-3 py-2 rounded-md bg-primary text-primary-foreground text-sm font-semibold hover:bg-primary/90 transition-colors flex items-center justify-center gap-1.5">
          <Check className="h-3.5 w-3.5" /> Spara
        </button>
        <button onClick={onClose} className="px-3 py-2 rounded-md border border-border text-sm text-muted-foreground hover:text-foreground transition-colors">
          Avbryt
        </button>
      </div>
    </div>
  );
}

function PricingEditForm({ customer, onClose }: { customer: CustomerProfile; onClose: () => void }) {
  const [price, setPrice] = useState(String(customer.monthly_price));
  const [interval, setInterval] = useState(customer.subscription_interval);

  return (
    <div className="space-y-3">
      <EditField label="Månadspris (kr)" value={price} onChange={setPrice} type="number" />
      <div>
        <div className="text-[11px] text-muted-foreground uppercase tracking-wider mb-1">Intervall</div>
        <select
          value={interval}
          onChange={(e) => setInterval(e.target.value as "month" | "quarter" | "year")}
          className="w-full px-3 py-2 rounded-md border border-border bg-card text-sm text-foreground outline-none focus:border-primary/30"
        >
          <option value="month">Månadsvis</option>
          <option value="quarter">Kvartalsvis</option>
          <option value="year">Årsvis</option>
        </select>
      </div>
      <div className="flex gap-2 pt-2">
        <button onClick={onClose} className="flex-1 px-3 py-2 rounded-md bg-primary text-primary-foreground text-sm font-semibold hover:bg-primary/90 transition-colors flex items-center justify-center gap-1.5">
          <Check className="h-3.5 w-3.5" /> Spara
        </button>
        <button onClick={onClose} className="px-3 py-2 rounded-md border border-border text-sm text-muted-foreground hover:text-foreground transition-colors">
          Avbryt
        </button>
      </div>
    </div>
  );
}

function AddLineItemForm({ onAdd, onClose }: { onAdd: (item: { description: string; amount: number; quantity: number }) => void; onClose: () => void }) {
  const [desc, setDesc] = useState("");
  const [amount, setAmount] = useState("");

  return (
    <div className="mt-3 p-3 rounded-lg border border-primary/20 bg-primary/5">
      <div className="text-xs font-semibold text-foreground mb-2">Ny rad</div>
      <div className="grid grid-cols-2 gap-2 mb-2">
        <EditField label="Beskrivning" value={desc} onChange={setDesc} placeholder="t.ex. Inspelningshjälp" />
        <EditField label="Belopp (kr)" value={amount} onChange={setAmount} type="number" placeholder="500" />
      </div>
      <div className="flex gap-2">
        <button
          onClick={() => {
            if (desc && amount) {
              onAdd({ description: desc, amount: Number(amount) * 100, quantity: 1 });
            }
          }}
          className="px-3 py-1.5 rounded-md bg-primary text-primary-foreground text-xs font-semibold hover:bg-primary/90 transition-colors"
        >
          Lägg till
        </button>
        <button onClick={onClose} className="px-3 py-1.5 rounded-md border border-border text-xs text-muted-foreground hover:text-foreground transition-colors">
          Avbryt
        </button>
      </div>
    </div>
  );
}

function EditField({ label, value, onChange, placeholder, type = "text" }: {
  label: string; value: string; onChange: (v: string) => void; placeholder?: string; type?: string;
}) {
  return (
    <div>
      <div className="text-[11px] text-muted-foreground uppercase tracking-wider mb-1">{label}</div>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full px-3 py-2 rounded-md border border-border bg-card text-sm text-foreground outline-none focus:border-primary/30"
      />
    </div>
  );
}
