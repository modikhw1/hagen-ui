import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { mockTeam, mockCustomers, mockTikTokStats, getCMActivityStats, type TeamMember } from "@/data/mock-admin";
import { X, Check, Users } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  HoverCard,
  HoverCardContent,
  HoverCardTrigger,
} from "@/components/ui/hover-card";

function ActivityBar({ count, max }: { count: number; max: number }) {
  const ratio = max > 0 ? Math.min(count / max, 1) : 0;
  const hue = ratio * 120;
  return (
    <div className="h-2 w-20 bg-accent rounded-full overflow-hidden" title={`${count} händelser`}>
      <div
        className="h-full rounded-full transition-all"
        style={{
          width: `${Math.max(ratio * 100, 8)}%`,
          backgroundColor: `hsl(${hue}, 60%, 45%)`,
        }}
      />
    </div>
  );
}

function WorkflowDot({ active }: { active: boolean }) {
  return (
    <div
      className={`w-1.5 h-1.5 rounded-full shrink-0 ${active ? "bg-success" : "bg-muted-foreground/30"}`}
    />
  );
}

export default function Team() {
  const navigate = useNavigate();
  const [editingCM, setEditingCM] = useState<string | null>(null);
  const maxActivity = Math.max(...mockTeam.map(cm => getCMActivityStats(cm.id).count7d), 1);

  const cmData = mockTeam.map((cm) => {
    const customers = mockCustomers.filter(
      (c) => c.account_manager === cm.name && c.status !== "archived"
    );
    const mrr = customers
      .filter((c) => c.status === "active" || c.status === "agreed")
      .reduce((s, c) => s + (c.monthly_price || 0), 0);
    const activity = getCMActivityStats(cm.id);
    return { ...cm, customers, mrr, activity };
  });

  const editingCMData = editingCM ? cmData.find(c => c.id === editingCM) : null;

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold font-heading text-foreground">Team</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Content Managers
          </p>
        </div>
        <button className="px-4 py-2 bg-primary text-primary-foreground rounded-md text-sm font-semibold">
          + Lägg till
        </button>
      </div>

      <div className="space-y-4">
        {cmData.map((cm) => (
          <div
            key={cm.id}
            className="bg-card rounded-lg border border-border p-5"
          >
            <div className="flex items-center gap-4 mb-4">
              <div
                className="w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold text-primary-foreground shrink-0"
                style={{ backgroundColor: cm.color }}
              >
                {cm.name.charAt(0)}
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-semibold text-foreground">{cm.name}</div>
                <div className="text-xs text-muted-foreground">{cm.city || cm.email}</div>
              </div>
              <div className="flex items-center gap-6 shrink-0">
                <CMStat label="Kunder" value={cm.customers.length} />
                <HoverCard openDelay={200}>
                  <HoverCardTrigger asChild>
                    <div className="text-right cursor-help">
                      <div className="text-sm font-semibold text-foreground">{cm.mrr.toLocaleString()} kr</div>
                      <div className="text-[11px] text-muted-foreground">MRR</div>
                    </div>
                  </HoverCardTrigger>
                  <HoverCardContent side="top" className="w-56 p-3">
                    <div className="space-y-2 text-xs">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Total MRR</span>
                        <span className="font-semibold text-foreground">{cm.mrr.toLocaleString()} kr</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">~20% ersättning</span>
                        <span className="font-semibold text-foreground">{Math.round(cm.mrr * 0.2).toLocaleString()} kr</span>
                      </div>
                      <div className="border-t border-border pt-1.5 text-[11px] text-muted-foreground">
                        Baserat på total MRR för servade kunder
                      </div>
                    </div>
                  </HoverCardContent>
                </HoverCard>
                <div className="flex flex-col items-end gap-1">
                  <ActivityBar count={cm.activity.count7d} max={maxActivity} />
                  <div className="text-[11px] text-muted-foreground">7d aktivitet</div>
                </div>
              </div>
              <button
                onClick={() => setEditingCM(cm.id)}
                className="shrink-0 px-3 py-1.5 rounded-md border border-border text-xs font-medium text-muted-foreground hover:text-foreground hover:bg-accent transition-colors"
              >
                Redigera
              </button>
            </div>

            {/* Customer list */}
            {cm.customers.length > 0 && (
              <div className="border-t border-border pt-3">
                <div className="grid grid-cols-[2fr_1fr_1fr_1fr] gap-2 px-2 pb-2 text-[11px] font-semibold text-muted-foreground uppercase tracking-wider">
                  <div>Kund</div>
                  <div className="text-right">MRR</div>
                  <div className="text-right">Följare</div>
                  <div className="text-right">Flöde</div>
                </div>
                {cm.customers.map((c) => {
                  const stats = mockTikTokStats[c.id];
                  const hasRecentUpload = c.last_upload_at && (new Date("2026-04-15T12:00:00Z").getTime() - new Date(c.last_upload_at).getTime()) < 3 * 24 * 60 * 60 * 1000;
                  const hasClips = (stats?.videos_last_7d || 0) > 0;
                  return (
                    <div
                      key={c.id}
                      className="grid grid-cols-[2fr_1fr_1fr_1fr] gap-2 px-2 py-2 rounded hover:bg-accent/30 transition-colors items-center cursor-pointer"
                      onClick={() => navigate(`/admin/customers/${c.id}`)}
                    >
                      <div className="flex items-center gap-2">
                        <span
                          className="w-1.5 h-1.5 rounded-full shrink-0"
                          style={{
                            backgroundColor:
                              c.status === "active" || c.status === "agreed"
                                ? "hsl(var(--success))"
                                : c.status === "invited"
                                  ? "hsl(var(--info))"
                                  : "hsl(var(--warning))",
                          }}
                        />
                        <span className="text-sm text-foreground">{c.business_name}</span>
                      </div>
                      <div className="text-sm text-foreground text-right">
                        {c.monthly_price > 0 ? `${c.monthly_price.toLocaleString()} kr` : "—"}
                      </div>
                      <div className="text-sm text-foreground text-right">
                        {stats?.followers ? stats.followers.toLocaleString() : "—"}
                      </div>
                      <div className="flex items-center justify-end gap-1">
                        <WorkflowDot active={hasRecentUpload || false} />
                        <WorkflowDot active={hasClips} />
                        <WorkflowDot active={(stats?.engagement_rate || 0) > 3} />
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        ))}
      </div>

      {/* CM Edit Modal */}
      {editingCMData && (
        <CMEditDialog
          cm={editingCMData}
          allCMs={mockTeam}
          onClose={() => setEditingCM(null)}
        />
      )}
    </div>
  );
}

function CMStat({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="text-right">
      <div className="text-sm font-semibold text-foreground">{value}</div>
      <div className="text-[11px] text-muted-foreground">{label}</div>
    </div>
  );
}

function CMEditDialog({ cm, allCMs, onClose }: { cm: TeamMember & { customers: any[] }; allCMs: TeamMember[]; onClose: () => void }) {
  const [name, setName] = useState(cm.name);
  const [email, setEmail] = useState(cm.email);
  const [phone, setPhone] = useState((cm as any).phone || "");
  const [city, setCity] = useState(cm.city || "");
  const [bio, setBio] = useState(cm.bio || "");
  const [reassignTo, setReassignTo] = useState("");

  const otherCMs = allCMs.filter(c => c.id !== cm.id && c.is_active);

  return (
    <Dialog open onOpenChange={(open) => { if (!open) onClose(); }}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Redigera CM</DialogTitle>
          <DialogDescription>Uppdatera profil och hantera kunder</DialogDescription>
        </DialogHeader>

        <div className="flex items-center gap-4 mb-4">
          <div
            className="w-14 h-14 rounded-full flex items-center justify-center text-lg font-bold text-primary-foreground shrink-0 relative group"
            style={{ backgroundColor: cm.color }}
          >
            {cm.name.charAt(0)}
            <div className="absolute inset-0 rounded-full bg-foreground/20 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity cursor-pointer">
              <span className="text-[10px] text-primary-foreground font-medium">Byt</span>
            </div>
          </div>
          <div className="flex-1">
            <div className="text-sm font-semibold text-foreground">{cm.name}</div>
            <div className="text-xs text-muted-foreground">{cm.role === "content_manager" ? "Content Manager" : cm.role}</div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3 mb-3">
          <EditField label="Namn" value={name} onChange={setName} />
          <EditField label="E-post" value={email} onChange={setEmail} />
          <EditField label="Telefon" value={phone} onChange={setPhone} placeholder="070-XXX XX XX" />
          <EditField label="Ort" value={city} onChange={setCity} placeholder="t.ex. Stockholm" />
          <div className="col-span-2">
            <div className="text-[11px] text-muted-foreground uppercase tracking-wider mb-1">Kort bio</div>
            <textarea
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              rows={2}
              className="w-full px-3 py-2 rounded-md border border-border bg-card text-sm text-foreground outline-none focus:border-primary/30 resize-none"
            />
          </div>
        </div>

        {/* Reassign customers */}
        {cm.customers.length > 0 && (
          <div className="border-t border-border pt-3 mb-3">
            <div className="text-[11px] text-muted-foreground uppercase tracking-wider mb-2">Omfördela alla kunder</div>
            <div className="flex gap-2">
              <select
                value={reassignTo}
                onChange={(e) => setReassignTo(e.target.value)}
                className="flex-1 px-3 py-2 rounded-md border border-border bg-card text-sm text-foreground outline-none focus:border-primary/30"
              >
                <option value="">Välj CM...</option>
                {otherCMs.map(c => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
              <button
                disabled={!reassignTo}
                className="px-3 py-2 rounded-md border border-border text-sm font-medium text-foreground hover:bg-accent disabled:opacity-40 transition-colors flex items-center gap-1.5"
              >
                <Users className="h-3.5 w-3.5" /> Flytta {cm.customers.length} kunder
              </button>
            </div>
          </div>
        )}

        <div className="flex gap-2 pt-2">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-md bg-primary text-primary-foreground text-sm font-semibold hover:bg-primary/90 transition-colors flex items-center gap-1.5"
          >
            <Check className="h-3.5 w-3.5" /> Spara
          </button>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-md border border-border text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            Avbryt
          </button>
          <div className="flex-1" />
          <button
            className="px-4 py-2 rounded-md border border-destructive/30 text-sm text-destructive hover:bg-destructive/5 transition-colors"
          >
            Arkivera CM
          </button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function EditField({ label, value, onChange, placeholder, type = "text" }: {
  label: string; value: string; onChange: (v: string) => void; placeholder?: string; type?: string;
}) {
  return (
    <div>
      <div className="text-[11px] text-muted-foreground uppercase tracking-wider mb-1">{label}</div>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full px-3 py-2 rounded-md border border-border bg-card text-sm text-foreground outline-none focus:border-primary/30"
      />
    </div>
  );
}
