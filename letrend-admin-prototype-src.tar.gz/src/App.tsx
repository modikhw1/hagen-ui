import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes, Navigate } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import AdminLayout from "@/components/admin/AdminLayout";
import Overview from "@/pages/admin/Overview";
import Customers from "@/pages/admin/Customers";
import Billing from "@/pages/admin/Billing";
import Team from "@/pages/admin/Team";
import CustomerDetail from "@/pages/admin/CustomerDetail";
import NotFound from "./pages/NotFound.tsx";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Navigate to="/admin" replace />} />
          <Route
            path="/admin"
            element={
              <AdminLayout>
                <Overview />
              </AdminLayout>
            }
          />
          <Route
            path="/admin/customers"
            element={
              <AdminLayout>
                <Customers />
              </AdminLayout>
            }
          />
          <Route
            path="/admin/customers/:id"
            element={
              <AdminLayout>
                <CustomerDetail />
              </AdminLayout>
            }
          />
          <Route
            path="/admin/billing"
            element={
              <AdminLayout>
                <Billing />
              </AdminLayout>
            }
          />
          <Route
            path="/admin/team"
            element={
              <AdminLayout>
                <Team />
              </AdminLayout>
            }
          />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
