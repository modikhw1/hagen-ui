import { ReactNode } from "react";
import { NavLink, useLocation } from "react-router-dom";
import {
  LayoutDashboard,
  Users,
  CreditCard,
  UsersRound,
  LogOut,
} from "lucide-react";

const SIDEBAR_WIDTH = 240;

const navItems = [
  { href: "/admin", label: "Översikt", icon: LayoutDashboard, exact: true },
  { href: "/admin/customers", label: "Kunder", icon: Users },
  { href: "/admin/billing", label: "Billing", icon: CreditCard },
  { href: "/admin/team", label: "Team", icon: UsersRound },
];

function SidebarLink({
  href,
  label,
  icon: Icon,
  exact,
}: {
  href: string;
  label: string;
  icon: React.ElementType;
  exact?: boolean;
}) {
  const location = useLocation();
  const isActive = exact
    ? location.pathname === href
    : location.pathname.startsWith(href);

  return (
    <NavLink
      to={href}
      end={exact}
      className={`flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors ${
        isActive
          ? "bg-accent text-foreground"
          : "text-muted-foreground hover:bg-accent/50 hover:text-foreground"
      }`}
    >
      <Icon className="h-4 w-4 shrink-0" />
      <span>{label}</span>
    </NavLink>
  );
}

export default function AdminLayout({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-screen bg-background">
      {/* Sidebar */}
      <aside
        className="fixed top-0 left-0 h-screen bg-secondary border-r border-border flex flex-col z-50"
        style={{ width: SIDEBAR_WIDTH }}
      >
        {/* Brand */}
        <div className="px-5 py-5 border-b border-border">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-md bg-primary flex items-center justify-center">
              <span className="text-primary-foreground text-xs font-bold">LT</span>
            </div>
            <div>
              <div className="text-base font-semibold font-heading leading-tight text-foreground">
                LeTrend
              </div>
              <div className="text-[11px] text-muted-foreground uppercase tracking-wider">
                Admin
              </div>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-3 py-4 flex flex-col gap-1">
          {navItems.map((item) => (
            <SidebarLink key={item.href} {...item} />
          ))}
        </nav>

        {/* Footer */}
        <div className="px-3 py-4 border-t border-border space-y-2">
          <div className="px-3 py-2 rounded-md bg-accent/50">
            <div className="text-xs font-medium text-foreground truncate">
              admin
            </div>
            <div className="text-[11px] text-muted-foreground truncate">
              admin@letrend.se
            </div>
          </div>
          <button className="w-full flex items-center gap-2 px-3 py-2 rounded-md text-sm text-muted-foreground hover:bg-accent/50 hover:text-foreground transition-colors">
            <LogOut className="h-3.5 w-3.5" />
            <span>Logga ut</span>
          </button>
        </div>
      </aside>

      {/* Main content */}
      <main
        className="flex-1 min-h-screen"
        style={{ marginLeft: SIDEBAR_WIDTH }}
      >
        <div className="p-8 max-w-[1080px]">
          {children}
        </div>
      </main>
    </div>
  );
}
