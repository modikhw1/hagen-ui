# LeTrend — Demo Feed Plan: Full Context for External Agent

## What this package covers

The **demo landing page** (`/d/:token`) is a public, unauthenticated page shown to
prospective customers. Its centrepiece is a 3×3 TikTok-style feed grid that pulls live
data from the same Studio feed planner the content managers use. This package contains
every source file, data sample and note an external agent needs to understand, modify or
extend that grid.

---

## Monorepo layout (relevant parts only)

```
artifacts/
  api-server/src/routes/
    public.ts              ← demo API endpoint + loadPreviewConcepts (MAIN FILE)
    studio-v2.ts           ← concept CRUD, PATCH /concepts/:id, insert defaults
  letrend/src/
    app/d/[token]/
      page.tsx             ← data-fetching wrapper (useEffect + fetch)
      DemoLandingView.tsx  ← full page layout; passes concepts[] to CustomerPlannerGrid
    components/demo/
      CustomerPlannerGrid.tsx  ← the 3×3 feed grid (MAIN COMPONENT)
    lib/studio/planner/
      queue-updates.ts     ← dense-queue sort logic (mirrored in public.ts)
docs/
  demo-feed-plan-data-objects.md  ← human-readable field reference
sample/
  api-response-sample.json  ← live truncated API response (2 kommande + 2 historik)
```

---

## Data flow

```
Browser (page.tsx)
  └─ fetch /api/public/demos/:token
       └─ public.ts: GET /api/public/demos/:token
            ├─ demos table     → demo metadata, CM info, game plan
            ├─ customer_profiles → company name, tiktok handle
            └─ loadPreviewConcepts(supabase, customerId)
                 └─ customer_concepts JOIN concepts
                      ├─ futurePlanned  (feed_order ≥ 0, status != history_import)
                      │    sort: feed_order → added_at → id   [dense queue]
                      │    assign: positions 0, 1, 2, 3, ...
                      ├─ explicitPast   (feed_order < 0, status != history_import)
                      │    kept as-is (set by advance_customer_feed_plan RPC)
                      └─ importedHistory (status = history_import, feed_order null)
                           sort: published_at DESC
                           assign: -1, -2, -3, ...
  └─ DemoPreviewPayload { demo, concepts: DemoPreviewConcept[] }
       └─ DemoLandingView.tsx
            └─ CustomerPlannerGrid slots={concepts}
```

---

## The dense-queue problem (why feed_order values cannot be trusted raw)

When a CM adds a concept through the Studio "Lägg till"-flow, the insert always sets
`feed_order = 1` (the Express default, `studio-v2.ts` line ~368). The Studio frontend
uses `buildDenseFeedOrderInsertionUpdates` (queue-updates.ts) to compute PATCH updates
that normalise positions to 0,1,2,… — but those PATCHes only fire when the CM
*explicitly drags or reassigns* a card. If the CM just adds 5 concepts without
reordering, they all stay at `feed_order = 1`.

The Studio's `buildFeedPlannerModel` handles this by sorting the queue the same way
(`feed_order → added_at → id`) and mapping indices to visual cells. The demo API now
replicates that logic in `loadPreviewConcepts` so the grid always matches what the CM
sees.

**Before fix (commit bb22457):** 5 concepts all at feed_order=1 → only 1 showed.  
**After fix (commit a49f617):** dense-queue normalisation → Nu + 4 kommande all render.

---

## customer_concepts table — key columns

| Column | Type | Notes |
|---|---|---|
| `id` | uuid PK | |
| `customer_profile_id` | uuid FK | links to customer_profiles |
| `concept_id` | uuid FK nullable | links to concepts library; null for history imports |
| `feed_order` | int nullable | ≥0 = future queue; <0 = past; null = unscheduled |
| `status` | text | `draft`, `produced`, `archived`, `history_import` |
| `row_kind` | text | `assignment`, `collaboration`, `history_import` |
| `history_source` | text nullable | `tiktok_profile` for TikTok imports |
| `added_at` | timestamptz | tie-break for dense queue sort |
| `tiktok_url` | text nullable | TikTok video URL |
| `tiktok_thumbnail_url` | text nullable | CDN thumbnail URL |
| `tiktok_views` | int nullable | view count |
| `tiktok_likes` | int nullable | ⚠️ not yet exposed in DemoPreviewConcept |
| `tiktok_comments` | int nullable | ⚠️ not yet exposed in DemoPreviewConcept |
| `content_overrides` | jsonb | CM overrides: headline, thumbnail_url, why_it_fits … |
| `tags` | text[] | concept tags |
| `cm_note` | text nullable | falls back into whyFits |
| `reconciled_customer_concept_id` | uuid nullable | links history row to its assignment |
| `published_at` | timestamptz nullable | publish date (history imports) |

**concepts table (joined):**
| Column | Notes |
|---|---|
| `backend_data` | jsonb blob: headline_sv, whyItWorks_sv, whyItFits_sv, cover_image_url, source_url … |
| `overrides` | jsonb: headline_sv, whyItWorks_sv, whyItFits_sv |

---

## DemoPreviewConcept — API shape

```typescript
type DemoPreviewConcept = {
  id: string;
  feedOrder: number;        // 0=Nu, 1,2,…=kommande, -1,-2,…=historik
  title: string;
  source: 'letrend' | 'tiktok' | 'imported_history';
  tag: string | null;
  thumbnailUrl: string | null;  // null for kommande (no thumbnail set yet)
  publishedAt: string | null;   // ISO 8601, set for history
  views: number | null;         // set for history
  headline: string | null;
  whyWorks: string | null;      // null for history
  whyFits: string | null;       // null for history
  originalUrl: string | null;   // TikTok inspiration URL (kommande) or video URL (history)
};
```

---

## CustomerPlannerGrid — grid mechanics

```
TOTAL_SLOTS = 9   (3 columns × 3 rows)
CURRENT_SLOT_INDEX = 4   (centre cell = "Nu", feedOrder 0)
feedOrder(slotIndex) = 4 − slotIndex + windowOffset

slotIndex  feedOrder (windowOffset=0)
    0          +4   (top-left  = fourth upcoming)
    1          +3
    2          +2
    3          +1   (second upcoming)
    4           0   ← Nu
    5          -1   (most recent history)
    6          -2
    7          -3
    8          -4   (bottom-right = fourth-most-recent history)
```

Navigation buttons shift `windowOffset` by ±3 (one row at a time).

### Card states

| State | `slot` | Rendered by | Visual |
|---|---|---|---|
| Filled (kommande/Nu) | not null | `FilledCell` | White/blush bg; LeT badge; hover shows whyWorks/whyFits |
| Filled (historik) | not null | `FilledCell` | Thumbnail bg; TT badge; views + date |
| Empty Nu (no concept assigned) | null, feedOrder=0 | `EmptyCell` | "Nästa steg är klart i planen" or "…förbereds av er CM" |
| Empty historik | null, feedOrder<0 | `EmptyCell` | Short dash line |
| Empty kommande | null, feedOrder>0 | `EmptyCell` | Invisible |

### Badge logic
```
isNow=true          → "Nu"   (always, gold border)
source=tiktok/imported_history → "TT"   (blush pill)
source=letrend      → "LeT"  (brown pill)
```

---

## Known gaps / open work

| # | Gap | Where | Priority |
|---|---|---|---|
| 1 | **Thumbnail missing for kommande** | `buildPreviewConcept` looks in `backend_data.cover_image_url` but LeT concepts often lack it | Medium |
| 2 | **likes/comments not exposed** | `tiktok_likes`, `tiktok_comments` exist in DB and are merged but not in `DemoPreviewConcept` type | Low |
| 3 | **History title = always "TikTok-klipp"** | No `tiktok_description` column; `backend_data` for history rows usually empty | Low |
| 4 | **dense-queue only normalised at query time** | DB still stores colliding `feed_order=1`; studio PATCH is only triggered on explicit reorder | Info |

---

## Key API endpoints

| Method | Path | Auth | Description |
|---|---|---|---|
| GET | `/api/public/demos/:token` | none (public) | Returns full `DemoPreviewPayload` including concepts[] |
| PATCH | `/api/studio-v2/concepts/:conceptId` | CM/Admin | Updates concept fields incl. `feed_order`, `tags`, `tiktok_thumbnail_url` |
| POST | `/api/studio-v2/customers/:customerId/concepts` | CM/Admin | Inserts new concept; sets `feed_order=1` by default |

---

## Test token (dev only)

```
GET /api/public/demos/cc3e9594e3aa659fbca2183e063108ebc2c797
Customer: Consor (0cd8f4d8-8bb8-4456-ba85-1108b5e69a65)
Expected: 5 kommande (feedOrder 0–4) + 33 historik (feedOrder -1 to -33)
```
